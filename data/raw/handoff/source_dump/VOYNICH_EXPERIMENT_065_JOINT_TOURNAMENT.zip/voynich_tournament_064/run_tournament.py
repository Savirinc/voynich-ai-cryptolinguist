#!/usr/bin/env python3
"""Experiment 064, simultaneous Voynich hypothesis tournament.
Uses user-provided ZL3b-n IVTFF EVA DOCX and prior position CSV. No translations assumed.
Tests: character/syllable segmentation crossvalidation, A/B variety, q-context,
line-final m-vs-iin, label-vs-prose, zodiac ordinal alignments, crib constraints.
Folio-collection heldouts; reports original EVA log-loss, not normalized surrogate.
Requires python-docx, numpy, pandas, scipy, scikit-learn.
"""
from collections import Counter, defaultdict
from pathlib import Path
import re,math,json,csv,random,hashlib, statistics
import numpy as np,pandas as pd
from docx import Document
from scipy.spatial.distance import jensenshannon
from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score
from sklearn.model_selection import GroupKFold
HOME=Path('/mnt/data'); OUT=HOME/'voynich_tournament_064'; OUT.mkdir(exist_ok=True)
SEED=64014; rng=random.Random(SEED)

# Read transcription without relying on any earlier experimentally processed results.
folio_meta={};records=[]; word_re=re.compile(r'[a-z]{2,20}$'); seen=[]
for p in Document(HOME/'IVTFF Eva.txt.docx').paragraphs:
 s=p.text.strip()
 h=re.match(r'^<(f\d+[rv]\d*)>\s*<!([^>]+)>',s)
 if h:
  f,header=h.groups();folio_meta[f]={}
  for tag,key in [('L','lang'),('I','section'),('H','hand')]:
   v=re.search(r'\$'+tag+r'=([^\s$>]+)',header)
   folio_meta[f][key]=v.group(1) if v else '?'
 a=re.match(r'^<(f\d+[rv]\d*)\.(\d+),([^>]+)>\s*(.*)',s)
 if not a:continue
 f,num,loc,body=a.groups()
 mode='prose' if 'P' in loc else ('label' if 'L' in loc else ('circle' if 'C' in loc else 'other'))
 # IVTFF $ tokens for line end and uncertain readings deliberately not interpreted as characters.
 body=re.sub(r'<![^>]*>',' ',body)
 body=re.sub(r'<(?:%|\$|-)>','',body)
 words=[w for w in re.split(r'[.,\s]+',body) if w]
 valid=[w if word_re.fullmatch(w) else None for w in words]
 if not valid:continue
 records.append({'folio':f,'num':int(num),'loc':loc,'mode':mode,'raw':body,'tokens':valid,
                 'meta':folio_meta.get(f,{'lang':'?','section':'?','hand':'?'})})

observations=[];line_count=Counter();invalid=Counter(); running_lines=[]
for rec in records:
 items=rec['tokens'];line_count[rec['mode']]+=1
 leaf=re.match(r'f(\d+)',rec['folio']).group(1)
 for i,w in enumerate(items):
  if w is None:invalid[rec['mode']]+=1;continue
  prev=items[i-1] if i>0 else None
  observations.append(dict(word=w,folio=rec['folio'],leaf=leaf,mode=rec['mode'],
      variety=rec['meta']['lang'],section=rec['meta']['section'],hand=rec['meta']['hand'],
      prev=prev if prev is not None else '^LINE',prev_y=int(bool(prev) and prev.endswith('y')),
      prev_end=(prev[-1] if prev else '^'),start=int(i==0),end=int(i==len(items)-1),
      line=rec['num']))
 if rec['mode']=='prose':running_lines.append(rec)
prose=[x for x in observations if x['mode']=='prose']; labels=[x for x in observations if x['mode']=='label']
counter=Counter(x['word'] for x in prose)
A=[r for r in prose if r['variety']=='A'];B=[r for r in prose if r['variety']=='B']
summary={'source':'ZL3b-n v3b, 13 May 2025, user-provided docx',
 'source_sha256':hashlib.sha256((HOME/'IVTFF Eva.txt.docx').read_bytes()).hexdigest(),
 'lines_by_mode':dict(line_count),'invalid_parts_by_mode':dict(invalid),
 'prose_tokens':len(prose),'prose_types':len(counter),'label_tokens':len(labels),
 'prose_folios':len(set(x['folio'] for x in prose)),'prose_leaves':len(set(x['leaf'] for x in prose)),
 'Currier_A':len(A),'Currier_B':len(B)}

# Alphabet/position inventory. Common EVA characters are *not* phonemes.
charpos=defaultdict(lambda:[0,0,0]); charfreq=Counter()
for r in prose:
 w=r['word']
 for j,c in enumerate(w):
  charfreq[c]+=1;charpos[c][0 if j==0 else (2 if j==len(w)-1 else 1)]+=1
summary['glyph_1char_frequencies']=dict(charfreq.most_common())
glyphrows=[{'eva_symbol':x,'total':charfreq[x],'word_initial':v[0],'word_internal':v[1],'word_final':v[2],
            'percent_initial':round(v[0]/sum(v)*100,2),'percent_final':round(v[2]/sum(v)*100,2)} for x,v in sorted(charpos.items())]
pd.DataFrame(glyphrows).to_csv(OUT/'glyph_position_table.csv',index=False)

# Robust folds by numbered physical leaf; cache distribution assignments by deterministic hash.
leaves=sorted({r['leaf'] for r in prose},key=lambda k:int(k))
fold_of={leaf:int(hashlib.sha256(('v064:'+leaf).encode()).hexdigest()[:8],16)%5 for leaf in leaves}
summary['prose_folds']={str(k):sum(fold_of[x['leaf']]==k for x in prose) for k in range(5)}

# Small, fixed ngram models; preserve full original word likelihood when chunking.
class UnitLM:
 def __init__(self,words, chunks, context=2, alpha=.2):
  self.chunks=sorted(chunks,key=len,reverse=True)
  self.context=context;self.alpha=alpha
  self.count=defaultdict(Counter);self.total=Counter();self.vocab=set(['$'])
  for w in words:
   seq=self.units(w);self.vocab.update(seq)
  self.V=len(self.vocab)+1
  for w in words:
   seq=['^']*context+self.units(w)+['$']
   for i in range(context,len(seq)):
    key=tuple(seq[i-context:i]);x=seq[i]
    self.count[key][x]+=1;self.total[key]+=1
 def units(self,w):
  result=[];i=0
  while i<len(w):
   match=next((z for z in self.chunks if w.startswith(z,i)),None)
   if match:result.append(match);i+=len(match)
   else:result.append(w[i]);i+=1
  return result
 def bits(self,w):
  seq=['^']*self.context+self.units(w)+['$']; s=0
  for i in range(self.context,len(seq)):
   key=tuple(seq[i-self.context:i]);x=seq[i]
   p=(self.count[key][x]+self.alpha)/(self.total[key]+self.alpha*self.V)
   s-=math.log2(p)
  return s

strategies={
 'EVA_raw':[],
 'minim_groups':['iiin','iin','in'],
 'bench_glyphs':['cth','ckh','cph','cfh','ch','sh'],
 'qo_and_bench':['cth','ckh','cph','cfh','ch','sh','qo'],
 'learned_8':['ch','dy','ai','ok','ol','sh','in','aiin'],
 'common_endings_control':['dy','ey','ar','al','ai','oi','am','or']
}
# exact EVA surface heldout bits per word, equivalent to a unique concatenation
# path for deterministic greedy chunking. Predictive improvement does not establish glyph identity.
rows=[];fold_data={}
for fold in range(5):
 train=[r['word'] for r in prose if fold_of[r['leaf']]!=fold]
 test=[r['word'] for r in prose if fold_of[r['leaf']]==fold]
 for strategy,chunks in strategies.items():
  for context in [2,3]:
   lm=UnitLM(train,chunks,context=context)
   losses=[lm.bits(w) for w in test]
   rows.append({'fold':fold,'strategy':strategy,'context':context,'test_count':len(test),
                'bits_per_original_word':round(statistics.mean(losses),6),
                'bits_per_original_character':round(sum(losses)/sum(map(len,test)),6),
                'training_unit_vocab':lm.V})
pd.DataFrame(rows).to_csv(OUT/'segmentation_crossvalidation.csv',index=False)

# Candidate q prefix as context condition, no assumption of antonymy or shared meanings.
# Only o/qo word pairs with >1 observation for either on *training*, use models with unknown-stem category.
def logistic_cv(data,featuresets,stem_fun,target_fun):
 data=list(data); outcomes={}
 for model,fn in featuresets.items():
  allpred=[];alltruth=[];allmeta=[]; fold_results=[]
  for fold in range(5):
   train=[r for r in data if fold_of[r['leaf']]!=fold];test=[r for r in data if fold_of[r['leaf']]==fold]
   if not train or not test:continue
   freq=Counter(stem_fun(r) for r in train)
   def features(r):
    stem=stem_fun(r); d=fn(r).copy()
    d['stem']='s:'+stem if freq[stem]>=5 else '<RARE>'
    return d
   vec=DictVectorizer(sparse=True); X=vec.fit_transform([features(r) for r in train]); Xt=vec.transform([features(r) for r in test]);y=np.array([target_fun(r) for r in train]);yt=np.array([target_fun(r) for r in test])
   lr=LogisticRegression(C=.3,max_iter=220,solver='liblinear');lr.fit(X,y)
   pred=np.clip(lr.predict_proba(Xt)[:,1],1e-6,1-1e-6)
   err=log_loss(yt,pred,labels=[0,1])
   auc=roc_auc_score(yt,pred) if len(set(yt))==2 else None
   fold_results.append({'fold':fold,'n':len(test),'loss_nats':err,'auc':auc})
   allpred.extend(pred);alltruth.extend(yt);allmeta.extend(test)
  outcomes[model]={'logloss':round(log_loss(alltruth,allpred,labels=[0,1]),6),
                   'auc':round(roc_auc_score(alltruth,allpred),6),'test_tokens':len(alltruth),
                   'fold_results':fold_results}
 return outcomes

qdata=[r for r in prose if r['word'].startswith(('o','qo')) and r['prev']!='^LINE' and r['variety'] in 'AB']
qfeat={
 'stem+variety':lambda r:{'variety':r['variety']},
 '+prev_final_y':lambda r:{'variety':r['variety'],'prev_y':str(r['prev_y'])},
 '+prev_final_exact':lambda r:{'variety':r['variety'],'prev_last':r['prev_end']},
 '+prev_final_and_line':lambda r:{'variety':r['variety'],'prev_last':r['prev_end'],'line_end':str(r['end'])}
}
qeval=logistic_cv(qdata,qfeat,lambda r:r['word'][1:] if r['word'].startswith('q') else r['word'],lambda r:int(r['word'].startswith('q')))
qeval['unconditional_counts']={'eligible':len(qdata),'qo':sum(r['word'].startswith('qo') for r in qdata),
 'prev_y':sum(r['prev_y'] for r in qdata)}

# m-vs-iin: same visible stem groups, both forms must occur >=2 in overall dataset,
# but model crossvalidation never uses heldout to infer coefficients.
stem_counts=Counter((r['word'][:-1] if r['word'].endswith('m') else r['word'][:-3]) for r in prose if r['word'].endswith(('m','iin')))
m_raw=[r for r in prose if r['word'].endswith(('m','iin')) and len(r['word'])>=3 and r['variety'] in 'AB']
mtypes=Counter((r['word'][:-1] if r['word'].endswith('m') else r['word'][:-3],r['word'].endswith('m')) for r in m_raw)
valid_stems={stem for stem,is_m in mtypes if mtypes[(stem,True)]>=2 and mtypes[(stem,False)]>=2}
mdata=[r for r in m_raw if (r['word'][:-1] if r['word'].endswith('m') else r['word'][:-3]) in valid_stems]
mfeat={
 'stem+variety':lambda r:{'variety':r['variety']},
 '+line_end':lambda r:{'variety':r['variety'],'line_end':str(r['end'])},
 '+preceding_end':lambda r:{'variety':r['variety'],'prev_last':r['prev_end']},
 '+both':lambda r:{'variety':r['variety'],'prev_last':r['prev_end'],'line_end':str(r['end'])}
}
meval=logistic_cv(mdata,mfeat,lambda r:r['word'][:-1] if r['word'].endswith('m') else r['word'][:-3],lambda r:int(r['word'].endswith('m')))
meval['families']=len(valid_stems);meval['occurrences']=len(mdata)

# Label vs prose q and same-folio control. This does not equate labels with names.
label_by_folio=defaultdict(list); prose_by_folio=defaultdict(list)
for r in labels:label_by_folio[r['folio']].append(r)
for r in prose:prose_by_folio[r['folio']].append(r)
common_folios=sorted(set(label_by_folio)&set(prose_by_folio))
label_common=[r for f in common_folios for r in label_by_folio[f]]
prose_common=[r for f in common_folios for r in prose_by_folio[f]]
label_eval={'all_labels':len(labels),'labels_q':sum(r['word'].startswith('q') for r in labels),
 'all_prose':len(prose),'prose_q':sum(r['word'].startswith('q') for r in prose),
 'common_folios_count':len(common_folios), 'same_folio_labels':len(label_common),
 'same_folio_prose':len(prose_common),
 'same_folio_label_q':sum(r['word'].startswith('q') for r in label_common),
 'same_folio_prose_q':sum(r['word'].startswith('q') for r in prose_common)}

# Currier A/B comparison on herbal pages only controls subject/illustration class.
herbalA=[r for r in A if r['section']=='H'];herbalB=[r for r in B if r['section']=='H']
def top2_hist(rows):return Counter(r['word'][:2] for r in rows)
def js(a,b):
 c1=top2_hist(a);c2=top2_hist(b);keys=set(c1)|set(c2)
 p=np.array([c1[k] for k in keys],dtype=float);q=np.array([c2[k] for k in keys],dtype=float)
 return float(jensenshannon(p/p.sum(),q/q.sum(),base=2)**2)
obs_js=js(herbalA,herbalB)
# Shuffle Currier label among whole folios within herbals, preserving folio amounts and grouping.
by_folio=defaultdict(list)
for r in herbalA+herbalB:by_folio[r['folio']].append(r)
folios=list(by_folio); nA=len(set(r['folio'] for r in herbalA));null=[]
for z in range(400):
 shuffle=folios[:];rng.shuffle(shuffle);setA=set(shuffle[:nA]); aa=[];bb=[]
 for f in folios:(aa if f in setA else bb).extend(by_folio[f])
 null.append(js(aa,bb))
variety_eval={'herbal_only_A_tokens':len(herbalA),'herbal_only_B_tokens':len(herbalB),
             'Herbal_A_B_JS_divergence_bits':obs_js,
             'randomized_folio_labels_mean':float(np.mean(null)),
             'randomized_folio_labels_p':(1+sum(x>=obs_js for x in null))/(len(null)+1)}

# Zodiac: label form vs fixed provisional ordinal, testing cross-sign periodicity.
slot_path=HOME/'voynich_zodiac_slot_map.csv'
slots=pd.read_csv(slot_path).fillna('');zodiac=[]
for _,r in slots.iterrows():
 w=str(r['voynich_label'])
 if not re.fullmatch(r'[a-z]{2,20}',w):continue
 sign=str(r['sign']); ordinal=int(r['transcription_order'])-1
 zodiac.append({'sign':sign,'w':w,'prefix2':w[:2], 'ordinal':ordinal,
                'ring':str(r['ring']),'folio':str(r['folio'])})
# For each cyclic k, measure weighted JS dependence by position modulo k on prefix2.
# Null permutes within each sign and ring, preserving each sign/ring's vocabulary.
def zstat(zz,k):
 C=Counter(x['prefix2'] for x in zz);N=len(zz);group=defaultdict(Counter)
 for x in zz:group[x['ordinal']%k][x['prefix2']]+=1
 ent=0
 for bucket,ct in group.items():
  nb=sum(ct.values());
  for p,n in ct.items():
   ent+=(n/N)*math.log2((n/nb)/(C[p]/N))
 return ent
z_nulls={}; z_results={};
for k in [5,7,10,15,30]:
 obs=zstat(zodiac,k);null=[]
 for j in range(1000):
  copy=[x.copy() for x in zodiac]
  ix=defaultdict(list)
  for i,x in enumerate(copy):ix[(x['folio'],x['ring'])].append(i)
  for gi in ix.values():
   words=[copy[i]['prefix2'] for i in gi];rng.shuffle(words)
   for ind,prefix in zip(gi,words):copy[ind]['prefix2']=prefix
  null.append(zstat(copy,k))
 z_results[str(k)]={'MI_bits':round(obs,6),'null_mean_bits':round(float(np.mean(null)),6),
                    'p':round((1+sum(x>=obs for x in null))/(len(null)+1),6),
                    'usable':len(zodiac)}
# Note multiple comparisons: use max-over-k corrected p via synchronized permutation.

cribs=[
 {'crib':'Central Pisces star label = March','note':'Unverified referent: star label belongs to degree labels, later month name mars labels sign','status':'Cannot score as translation'},
 {'crib':'q = not/antonym','note':'Paired strings and contextual choice observed, no independently deciphered meaning','status':'No semantic identification'},
 {'crib':'q = plural','note':'Identical limitation: known grammatical number not anchored','status':'No semantic identification'},
 {'crib':'First ten zodiac labels = one to ten','note':'Cross-sign periodicity tests and former rotational controls do not establish corresponding numeral names','status':'Simple invariant spelling weakened'},
 {'crib':'Old French underlying text','note':'Later Romance month names do not determine language of earlier main script; no fixed phonetic correspondence','status':'Candidate, not decoded'},
 {'crib':'Latin underlying text','note':'Historically plausible lingua franca, but no mapping established','status':'Candidate, not decoded'},
 {'crib':'Occitan / Picard / German / Italian / Persian / Arabic / East Asian','note':'Need independently authenticated matched-genre historical corpora and explicit encoding model','status':'Open; no ranked language winner'},
]
pd.DataFrame(cribs).to_csv(OUT/'proposed_readings_audit.csv',index=False)

results={'experiment':'064','corpus':summary,'q_operator':qeval,'m_positional':meval,
 'labels_vs_prose':label_eval,'Currier_A_B':variety_eval,'zodiac_positions':z_results,
 'candidate_languages':{'corpora_compared_here':0,
  'status':'Not ranked: authenticated era-/genre-matched source texts not available in this environment. EVA is nonphonetic and naive character matches would be invalid.',
  'candidate_list':['Old French / Picard / Anglo-Norman','Latin','Occitan','Middle High German','Middle Dutch','Northern Italian','Persian','Arabic','other or artificial language']}}
(OUT/'results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False),encoding='utf8')
print(json.dumps({'tokens':summary['prose_tokens'],'labels':len(labels),'folds':summary['prose_folds'],
 'q_logloss':{a:b['logloss'] for a,b in qeval.items() if isinstance(b,dict) and 'logloss' in b},
 'm_logloss':{a:b['logloss'] for a,b in meval.items() if isinstance(b,dict) and 'logloss' in b},
 'AB':variety_eval,'zodiac':z_results},indent=2))
