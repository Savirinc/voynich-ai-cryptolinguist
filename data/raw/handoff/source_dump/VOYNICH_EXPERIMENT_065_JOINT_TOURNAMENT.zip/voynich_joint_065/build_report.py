#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,zipfile,shutil
import pandas as pd
import numpy as np
P=Path('/mnt/data/voynich_joint_065');R=P/'experiment_065_results.json';data=json.loads(R.read_text());sim=pd.read_csv(P/'joint_signature_scores.csv');place=json.loads((P/'context_placebo_summary.json').read_text());cur=json.loads((P/'currier_ablation_summary.json').read_text())
means=sim.groupby('model').mean(numeric_only=True)
fmt=lambda x:f'{x:.4f}'
lines=[]
lines += [
'# Voynich Experiment 065: Joint structural model tournament',
'',
'**Verdict:** the full manuscript has stable, predictable context-sensitive writing regularities. A model conditioned on transcription variety, annotation register, line endings and preceding-word endings improves held-out exact EVA prediction and reproduces several manuscript-level properties. **No language, cipher key, phonetic value, numerical names or decoded word is established.**',
'',
'## Data and experimental protections',
'',
'- Source: ZL3b-n IVTFF EVA version 3b (13 May 2025), user-supplied transcription. This run reused the conservative index built in Experiment 064; it did not re-OCR the original Yale images.',
'- 33,007 clean words (32,132 running words plus 875 isolated illustration labels), on 102 numbered physical leaves. Some disputed, unknown, or oddly segmented tokens were excluded.',
'- Five deterministic held-out folds grouped by physical leaf, not independent words. Fold sizes vary substantially. ALL reported prediction losses score the **actual original EVA words**, not rewritten normalized aliases.',
'- The Currier A/B label is **researcher-assigned on the full manuscript**; it is an oracle side-information feature, not an independently predicted property of unseen pages. We separately report a no-Currier ablation.',
'- Manuscript line-ending flag and picture-label versus prose type are supplied as observable layout annotations (not predicted by the model). This benchmark is *conditional transcription modeling*, not automatic decipherment.',
'',
'## Exact held-out prediction scores',
'',
'| Model | Weighted bits / original word | Improvement versus glyph-only | Wins across five folds |',
'|---|---:|---:|---:|'
]
base=data['model_scores_bits_word']['raw']
for model,label in [('raw','Glyph trigram only'),('style','Plus Currier A/B + caption/prose category'),('layout','Plus line-end position'),('context','Plus preceding-word final y')]:
 v=data['model_scores_bits_word'][model]; wins='baseline' if model=='raw' else f"{data['fold_deltas'][model]['wins']}/5"
 lines.append(f'| {label} | {v:.5f} | {base-v:+.5f} bits saved | {wins} |')
lines += [
'',f'The strongest model saves **{base-data["model_scores_bits_word"]["context"]:.5f} bits per word** ({100*(base-data["model_scores_bits_word"]["context"])/base:.2f}% of glyph-only prediction error). This is a structural forecast improvement, not recovered semantics.',
'',
'## Placebo controls: wrong context should not help',
'',
'| Context supplied to the trained model | Weighted bits/word |',
'|---|---:|',
 f'| True previous-word ending and line-end flag | {place["true_bits_weighted"]:.5f} |',
 f'| Preceding-word ending shuffled within leaf/register | {place["shuffle_prev_mean_bits_weighted"]:.5f} |',
 f'| Line-end flag shuffled within leaf/register | {place["shuffle_line_mean_bits_weighted"]:.5f} |',
 f'| Both shuffled, mean of three seeds | {place["shuffle_both_mean_bits_weighted"]:.5f} |',
'',
'Both individual context shuffles and the joint shuffle increased test loss in **all five folds**. Shuffling preserves approximate frequency distributions locally and breaks the meaningful associations. These are validation controls, not a null model for possible historical languages.',
'',
'## Ablation: how much depends on researcher-assigned Currier A/B?',
'',
'| Model | With Currier labels | Without Currier labels |',
'|---|---:|---:|'
]
for model in ['style','layout','context']:
 s=cur[model];lines.append(f'| {model} | {s["bits_with_researcher_currier"]:.5f} | {s["bits_without_currier"]:.5f} |')
lines += ['',f'With Currier assignments suppressed, the full context model achieves **{cur["context"]["bits_without_currier"]:.5f} bits/word**, still better than the **{base:.5f}** glyph-only baseline. Its extra gain with Currier known is *not* an independent, blind discovery of two historical languages.','',
'## Posterior predictive test: can the models reproduce the manuscript?',
'',
'On fold zero only, each model generated two word streams in held-out line/layout slots. Unlike mere next-character accuracy, this checks whether generated text resembles several real corpus statistics. For the context model, previous-word conditioning used the **generated** preceding words, not real unseen transcript words.',
'',
'| Diagnostic | Glyph-only | With register | With line-end | Full context | Better |',
'|---|---:|---:|---:|---:|---|'
]
met=[('glyph_unigram_JS_bits','Glyph frequency distribution (JS bits)','Lower'),('glyph_position_JS_bits','Initial/medial/final glyphs (JS bits)','Lower'),('word_length_JS_bits','Word lengths (JS bits)','Lower'),('q_context_gap_abs_error','Previous-y → initial-q effect (absolute rate error)','Lower'),('m_lineend_gap_abs_error','Line-end → final-m effect (absolute rate error)','Lower'),('A_B_prefix_JS_abs_error','Currier A/B bigram divergence (absolute error)','Lower'),('label_prose_q_gap_abs_error','Caption/prose q separation (absolute error)','Lower')]
for key,label,direct in met:
 vals=[means.loc[m,key] for m in ('raw','style','layout','context')];best=['raw','style','layout','context'][int(np.argmin(vals))]
 lines.append(f'| {label} | '+' | '.join(f'{x:.4f}' for x in vals)+f' | {best} |')
lines+=['',
'**Important failure:** the full context model still understates the preceding-`y`/initial-`q` effect. The held-out observed gap was **'+fmt(data['observed_signature']['q_context_gap'])+'**, but generated-text context models averaged **'+fmt(means.loc['context','sim_q_context_gap'])+'**. The generated word-length distribution is also imperfect. We have not reproduced the whole mechanism.',
'',
'## Historical-language comparison: not yet executed at corpus scale',
'',
'Authenticated public corpora were located, including Old French (`OpenMedFr/texts`) and Old Occitan/Gascon (`UD_Old_Occitan-CorAG`), but direct machine-readable downloads into this analysis environment failed. These repositories also differ from the Voynich manuscript in genre, date and editorial orthography. Consequently **there is no honest result ranking Old French, Latin, German, Occitan, Arabic, Persian or a constructed code**. We did not silently replace historical corpora with invented samples, modern dictionaries, or EVA-to-Latin string matches.',
'',
'Once corpora are accessible, use a split-by-document, era/genre-matched set of historical texts and compare: monoalphabetic substitution, many-to-one symbols, syllable/ligature encoding, positional allographs, word-boundary changes, context-sensitive transducers, and a grammar-free generator. Each mechanism must be fitted ONLY on training material, evaluated on held-out sections, and checked against the same seven joint signatures above. Chance similarities in the month annotations are not sufficient.',
'',
'## What stays in the evidence ledger',
'',
'| Claim | State | Reason |',
'|---|---|---|',
'| Word form depends on previous word ending | **Survives as a statistical property** | Improves unseen exact-word predictions; true metadata beats shuffled metadata |',
'| End-of-line spelling variation | **Survives as a statistical property** | Line flag helps original-word prediction, and simulations approach the observed final-m difference |',
'| A/B text variety | **Survives as a text distribution distinction** | Strong predictive difference when assignments are supplied; not proof of different plaintext languages |',
'| Captions/prose register distinction | **Survives as a writing difference** | Generation captures much of q scarcity in labels |',
'| `q` means negation, plural, or is always deletable | **Unproven / automatic deletion rejected earlier** | Predictive value does not reveal meaning; earlier placebo normalization failed |',
'| `m` means `iin`, `n` means `i`, or minims are single letters | **Unproven** | Original scan stroke audit and specificity controls inconclusive |',
'| Zodiac label words are numerals | **Not supported in simple form** | Earlier cross-sign tests did not survive all controls |',
'| `otral` means `mars` | **Unproven** | Later Romance annotations do not constitute bilingual translations |',
'| French, Latin, Occitan, German, Persian, Arabic underlying plaintext | **Open; not ranked** | Authentic corpora and cipher modeling have not yet been jointly validated |',
'| Structured non-semantic word generator | **Not excluded** | A model can reproduce structural features without yielding meaning |',
'',
'## Next decisive experiment',
'',
'Construct a pre-registered **image-text holdout**. Freeze a set of ten well-identified, high-resolution diagram items and historical named image-degree comparisons, then train hypothesized language/encoder mappings on other folios. Predict held-out text or semantic attributes *before* inspecting them. Repeat the same procedure with a structured no-semantics generator. A genuine externally verified semantic prediction would count as progress toward decipherment.',
'',
'## Reproduction',
'',
'Unzip the project into `/mnt/data/`, preserving the two sibling directories `voynich_tournament_064/` and `voynich_joint_065/`. Run:',
'',
'```bash',
'python /mnt/data/voynich_joint_065/run_joint.py',
'python /mnt/data/voynich_joint_065/context_placebos.py',
'python /mnt/data/voynich_joint_065/currier_ablation.py',
'python /mnt/data/voynich_joint_065/build_report.py',
'```',
'',
'You need `numpy`, `pandas` and the standard Python library. The supplied conservative input table is derived from the user-provided IVTFF source, included for provenance. Results are not evidence of successful decipherment.',
'',
'### Public sources',
'',
'- Yale Beinecke Manuscript 408: https://beinecke.library.yale.edu/beinecke/collections/beinecke-cipher-voynich-manuscript',
'- Open Medieval French texts: https://github.com/OpenMedFr/texts',
'- Old Occitan Corpus (CorAG): https://github.com/UniversalDependencies/UD_Old_Occitan-CorAG',
'']
(P/'EXPERIMENT_065_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
# Hash receipt proves actual files existed in current runtime.
inputs=[Path('/mnt/data/IVTFF Eva.txt.docx'), Path('/mnt/data/voynich_tournament_064/indexed_clean_corpus.csv')]
artifacts=['run_joint.py','context_placebos.py','currier_ablation.py','build_report.py','heldout_model_scores.csv','joint_signature_scores.csv','context_placebo_scores.csv','currier_ablation.csv','experiment_065_results.json','context_placebo_summary.json','currier_ablation_summary.json','EXPERIMENT_065_REPORT.md','synthetic_examples.json']
manifest={'experiment':'065','input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},'deliverables_sha256':{p:hashlib.sha256((P/p).read_bytes()).hexdigest() for p in artifacts}}
(P/'SHA256_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
zip_path=Path('/mnt/data/VOYNICH_EXPERIMENT_065_JOINT_TOURNAMENT.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
 for f in artifacts+['SHA256_MANIFEST.json']:
  z.write(P/f,'voynich_joint_065/'+f)
 # Data and parser to independently reconstruct source table; preserve names and paths.
 for f in inputs:
  arc='IVTFF Eva.txt.docx' if f.suffix=='.docx' else 'voynich_tournament_064/indexed_clean_corpus.csv'
  z.write(f,arc)
 z.write('/mnt/data/voynich_tournament_064/run_tournament.py','voynich_tournament_064/run_tournament.py')
 z.write('/mnt/data/voynich_zodiac_slot_map.csv','voynich_zodiac_slot_map.csv')
 z.write('/mnt/data/voynich_zodiac_clock_positions.csv','voynich_zodiac_clock_positions.csv')
print('Report:',(P/'EXPERIMENT_065_REPORT.md').stat().st_size,'bytes')
print('Archive:',zip_path.stat().st_size,'bytes')
