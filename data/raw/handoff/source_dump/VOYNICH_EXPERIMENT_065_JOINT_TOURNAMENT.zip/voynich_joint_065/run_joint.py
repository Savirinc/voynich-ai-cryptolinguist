#!/usr/bin/env python3
"""Experiment 065: six-signature posterior predictive model tournament.
Source: 064's conservative token table from ZL3b-n IVTFF v3b.
All spelling targets evaluated in *original* EVA, folio (physical leaf) held out.
No interpretation of EVA as phonetic values, no claimed decipherment.
"""
from __future__ import annotations
import csv, math, random, hashlib, json, collections, statistics
from pathlib import Path
import numpy as np
import pandas as pd
BASE=Path('/mnt/data'); ROOT=BASE/'voynich_joint_065'; ROOT.mkdir(exist_ok=True)
SRC=BASE/'voynich_tournament_064'/'indexed_clean_corpus.csv'
SEED=65014
raw=pd.read_csv(SRC, dtype={'folio':str,'leaf':str,'EVA':str,'Currier':str,'mode':str,'is_last_term':int},keep_default_na=False)
raw=raw[raw.EVA.str.fullmatch(r'[a-z]{2,20}')].copy()
# Interpret line neighbors strictly *within* a recorded manuscript line, and never through omitted uncertain words.
raw['roworder']=np.arange(len(raw))
raw=raw.sort_values(['folio','line_id','roworder'])
raw['prev_y']=False;raw['has_prev']=False
for (folio,lineid),group in raw.groupby(['folio','line_id'],sort=False):
 ids=group.index.to_list();positions=group['token_index_in_line'].tolist();words=group.EVA.tolist()
 for j in range(1,len(ids)):
  if positions[j]==positions[j-1]+1:
   raw.loc[ids[j],'prev_y']=words[j-1].endswith('y');raw.loc[ids[j],'has_prev']=True
raw['variety']=raw['Currier'].where(raw['Currier'].isin(['A','B']),other='?')
raw['end']=raw['is_last_term'].astype(int)
raw['prevcls']=raw['prev_y'].map({True:'y',False:'other'})
raw['fold']=raw.leaf.apply(lambda k: int(hashlib.sha256(('v064:'+str(k)).encode()).hexdigest()[:8],16)%5)
ALPH=sorted(set(''.join(raw.EVA.tolist())))+['$']
VOCAB=len(ALPH)
ALPHSET=set(ALPH)

class LM:
 def __init__(self, rows, mode='raw', k=28.0):
  self.mode=mode;self.k=k
  self.uni=collections.Counter();self.bi=collections.defaultdict(collections.Counter);self.tri=collections.defaultdict(collections.Counter)
  self.st=collections.defaultdict(collections.Counter);self.layout=collections.defaultdict(collections.Counter);self.prev=collections.defaultdict(collections.Counter)
  for r in rows:
   w=r.EVA;hs=['^','^'];style=(r.variety,r.mode);lay=(style,r.end);pr=(lay,r.prevcls)
   for j,c in enumerate(w+'$'):
    h=tuple(hs[-2:]);self.uni[c]+=1;self.bi[h[-1]][c]+=1;self.tri[h][c]+=1
    self.st[(style,h)][c]+=1;self.layout[(lay,h)][c]+=1
    if j==0:self.prev[(pr,h)][c]+=1
    hs.append(c)
  self.ut=sum(self.uni.values())
  self.cache={}
 def _smooth(self,count,x,prob,weight):
  return (count[x] + weight*prob)/(sum(count.values())+weight)
 def prob(self, h, c, style, end, prevcls, is_initial):
  key=(h,c,style,end,prevcls if is_initial else '-',is_initial)
  res=self.cache.get(key)
  if res is not None:return res
  pu=(self.uni[c]+0.2)/(self.ut+0.2*VOCAB)
  pb=self._smooth(self.bi[h[-1]],c,pu,24.)
  pt=self._smooth(self.tri[h],c,pb,24.)
  p=pt
  if self.mode in ('style','layout','context'):
   p=self._smooth(self.st[(style,h)],c,p,35.)
  if self.mode in ('layout','context'):
   p=self._smooth(self.layout[((style,end),h)],c,p,32.)
  if self.mode=='context' and is_initial:
   p=self._smooth(self.prev[(((style,end),prevcls),h)],c,p,26.)
  self.cache[key]=p
  return p
 def score(self,r):
  hs=['^','^'];style=(r.variety,r.mode);sm=0
  for j,c in enumerate(r.EVA+'$'):
   p=self.prob(tuple(hs[-2:]),c,style,r.end,r.prevcls,j==0)
   sm-=math.log2(max(1e-18,p));hs.append(c)
  return sm
 def sample(self,r,rng,prevcls=None, limit=24):
  hs=['^','^']; style=(r.variety,r.mode);w=[]
  cl=prevcls if prevcls is not None else r.prevcls
  for j in range(limit+1):
   h=tuple(hs[-2:]);pp=np.array([self.prob(h,c,style,r.end,cl,j==0) for c in ALPH]);pp/=pp.sum()
   x=rng.choices(ALPH,weights=pp,k=1)[0]
   if x=='$':break
   w.append(x);hs.append(x)
  return ''.join(w)

models=['raw','style','layout','context']
losses=[]
for fold in range(5):
 train=raw[raw.fold!=fold];test=raw[raw.fold==fold]
 print('FOLD',fold,len(train),len(test),flush=True)
 for model in models:
  lm=LM(train.itertuples(index=False),mode=model)
  bits=sum(lm.score(r) for r in test.itertuples(index=False));chars=test.EVA.str.len().sum()
  losses.append({'fold':fold,'model':model,'tokens':len(test),'characters':int(chars),'bits_per_word':bits/len(test),'bits_per_character':bits/chars})
  print(model,round(bits/len(test),4),flush=True)
loss=pd.DataFrame(losses);loss.to_csv(ROOT/'heldout_model_scores.csv',index=False)
weighted=loss.groupby('model').apply(lambda g: float(np.average(g.bits_per_word,weights=g.tokens)),include_groups=False).to_dict()

# Test 6 real distributional signatures on a fixed held-out fold with posterior predictive samples.
def jsdict(a,b):
 keys=set(a)|set(b)
 p=np.array([a.get(k,0) for k in keys],float)+1e-12;q=np.array([b.get(k,0) for k in keys],float)+1e-12
 p/=p.sum();q/=q.sum();v=(p+q)/2
 return float((np.sum(p*np.log2(p/v))+np.sum(q*np.log2(q/v)))/2)

def signatures(df):
 from collections import Counter
 words=df.word.tolist();wordlen=Counter(min(len(x),20) for x in words)
 allchars=Counter(''.join(words));positions=Counter();first=Counter();last=Counter()
 for w in words:
  if not w:continue
  first[w[0]]+=1;last[w[-1]]+=1
  for j,c in enumerate(w): positions[('initial' if j==0 else 'final' if j==len(w)-1 else 'internal',c)]+=1
 def rate(keep,pred):
  d=df[keep];return float(pred(d).mean()) if len(d) else None
 # For q dependency use words whose *previous* item ends in y or otherwise, and that start with o/qo.
 cq=df[(df.has_prev) & df.word.str.startswith(('o','qo'))]
 qr={c:float(g.word.str.startswith('q').mean()) for c,g in cq.groupby('prevcls') if len(g)>20}
 m_by={str(c):float(g.word.str.endswith('m').mean()) for c,g in df.groupby('end')}
 var_ab={str(c):Counter(w[:2] for w in g.word) for c,g in df[df.variety.isin(['A','B'])].groupby('variety')}
 register={str(c):float(g.word.str.startswith('q').mean()) for c,g in df.groupby('mode')}
 return {'unigram':allchars,'positional':positions,'word_length':wordlen,'q_rates':qr,'m_rates':m_by,'variety_prefix':var_ab,'register_q':register,
         'n':len(words),'mean_word_length':sum(map(len,words))/len(words),'vocab':len(set(words)),
         'q_gap':qr.get('y',0)-qr.get('other',0), 'm_gap':m_by.get('1',0)-m_by.get('0',0)}

test=raw[raw.fold==0].copy().reset_index(drop=True);train=raw[raw.fold!=0]
observed=test.copy();observed['word']=observed.EVA
obs=signatures(observed)
print('OBS_SIGNATURES',obs['q_gap'],obs['m_gap'],obs['mean_word_length'],flush=True)
# Generate a stream within lines; previous-y conditioning driven by generated predecessor, not the target transcript.
reports=[];simrecords=[]
for model in models:
 lm=LM(train.itertuples(index=False),mode=model)
 for replicate in [0,1]:
  rr=random.Random(13_159+replicate*1021+models.index(model)*10001)
  gen=[];prevword='';prevline=None
  for r in test.itertuples(index=False):
   lid=(r.folio,r.line_id)
   if lid!=prevline:prevword='';prevline=lid
   prev_cls=('y' if prevword.endswith('y') else 'other')
   word=lm.sample(r,rr,prevcls=prev_cls)
   gen.append(word);prevword=word
  sample=test.copy();sample['word']=gen
  # For q dependency use *generated* prev state.
  prev=[];yes=[];current_line=None;previous=''
  for r,w in zip(test.itertuples(index=False),gen):
   line=(r.folio,r.line_id)
   if line!=current_line:current_line=line;previous='';prev.append(False);yes.append(False)
   else:prev.append(True);yes.append(previous.endswith('y'))
   previous=w
  sample['has_prev']=prev;sample['prevcls']=['y' if x else 'other' for x in yes]
  sim=signatures(sample)
  metrics={
    'glyph_unigram_JS_bits':jsdict(obs['unigram'],sim['unigram']),
    'glyph_position_JS_bits':jsdict(obs['positional'],sim['positional']),
    'word_length_JS_bits':jsdict(obs['word_length'],sim['word_length']),
    'q_context_gap_abs_error':abs(obs['q_gap']-sim['q_gap']),
    'm_lineend_gap_abs_error':abs(obs['m_gap']-sim['m_gap']),
    'A_B_prefix_JS_abs_error':abs(jsdict(obs['variety_prefix'].get('A',{}),obs['variety_prefix'].get('B',{}))-jsdict(sim['variety_prefix'].get('A',{}),sim['variety_prefix'].get('B',{}))),
    'label_prose_q_gap_abs_error':abs((obs['register_q'].get('label',0)-obs['register_q'].get('prose',0))-(sim['register_q'].get('label',0)-sim['register_q'].get('prose',0))),
   }
  row={'model':model,'replicate':replicate,**metrics,'sim_q_context_gap':sim['q_gap'],'sim_m_lineend_gap':sim['m_gap'],'sim_mean_word_length':sim['mean_word_length'],'observed_q_context_gap':obs['q_gap'],'observed_m_lineend_gap':obs['m_gap'],'observed_mean_word_length':obs['mean_word_length']}
  reports.append(row)
  # save compact examples, not millions of synthetic words
  simrecords.append({'model':model,'replicate':replicate,'examples':gen[:20]})
  print('GEN',model,replicate,metrics,flush=True)
pd.DataFrame(reports).to_csv(ROOT/'joint_signature_scores.csv',index=False)

# empirical 5-fold paired difference (no false significance with only five folds)
fold_deltas={}
for model in models[1:]:
 base=loss[loss.model=='raw'].set_index('fold').bits_per_word
 alt=loss[loss.model==model].set_index('fold').bits_per_word
 fold_deltas[model]={'per_fold_bits_saved':list((base-alt).round(5)), 'wins':int(sum(base>alt)), 'mean_bits_saved':float((base-alt).mean())}
report={'experiment':'065','source':'IVTFF 2025 conservative extraction via Experiment 064','token_count':len(raw),'physical_leaves':int(raw.leaf.nunique()),
 'evaluation':'5-fold deterministic physical-leaf holdout, original EVA bits/word','model_scores_bits_word':weighted,
 'fold_deltas':fold_deltas,'signature_eval_fold':0,'observed_signature':{'q_context_gap':obs['q_gap'],'m_lineend_gap':obs['m_gap'],'Currier_AB_prefix_JS_bits':jsdict(obs['variety_prefix'].get('A',{}),obs['variety_prefix'].get('B',{})),
 'label_prose_initial_q_gap':obs['register_q'].get('label',0)-obs['register_q'].get('prose',0),'word_mean_length':obs['mean_word_length']},
 'assumptions':['Only conservative EVA strings from one transcriber','line-end and Currier metadata oracle given as conditioning context','derived context same-line adjacent tokens only','candidate historical corpora not successfully ingested','posterior predictive simulations are indicative, not semantic tests']}
(ROOT/'experiment_065_results.json').write_text(json.dumps(report,indent=2),encoding='utf8')
(ROOT/'synthetic_examples.json').write_text(json.dumps(simrecords,indent=2),encoding='utf8')
print('DONE',ROOT,flush=True)
