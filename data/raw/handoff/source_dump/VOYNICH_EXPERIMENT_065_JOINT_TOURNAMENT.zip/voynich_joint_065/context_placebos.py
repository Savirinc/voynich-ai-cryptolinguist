#!/usr/bin/env python3
"""Metadata falsification tests for 065 using same original-EVA scoring.
Permute conditioning variables among test rows while preserving distributions
inside each folio/mode/variety as well as possible. Correct context should
outperform randomly attached context if associations are real.
"""
from pathlib import Path
import numpy as np,pandas as pd,random,json
script=Path(__file__).with_name('run_joint.py').read_text()
base=script.split("models=['raw'")[0]
ns={'__name__':'voynich_placebo_support','__file__':str(Path(__file__).with_name('run_joint.py'))}
exec(compile(base,str(Path(__file__).with_name('run_joint.py')),'exec'),ns)
raw=ns['raw']; LM=ns['LM'];ROOT=ns['ROOT']
results=[]
for fold in range(5):
 train=raw[raw.fold!=fold];test=raw[raw.fold==fold]
 lm=LM(train.itertuples(index=False),mode='context')
 true_bits=sum(lm.score(r) for r in test.itertuples(index=False))/len(test)
 row={'fold':fold,'tokens':len(test),'true_bits':true_bits}
 for rep in range(3):
  rgen=np.random.default_rng(65014+fold*101+rep*10007)
  shuf=test.copy()
  # Shuffle each flag independently within physical leaf and mode; values remain believable.
  for col in ['prevcls','end']:
   shuf[col]=shuf.groupby(['leaf','mode'])[col].transform(lambda vals:rgen.permutation(vals.to_numpy()))
  bothbits=sum(lm.score(r) for r in shuf.itertuples(index=False))/len(shuf)
  row[f'joint_shuffle_{rep}_bits']=bothbits
  if rep==0:
   a=test.copy();a['prevcls']=shuf['prevcls']
   row['prev_shuffle_bits']=sum(lm.score(r) for r in a.itertuples(index=False))/len(a)
   b=test.copy();b['end']=shuf['end']
   row['line_shuffle_bits']=sum(lm.score(r) for r in b.itertuples(index=False))/len(b)
 results.append(row)
 print('FOLD',fold, {k:round(v,4) if isinstance(v,float) else v for k,v in row.items()}, flush=True)
p=pd.DataFrame(results);p.to_csv(ROOT/'context_placebo_scores.csv',index=False)
ss={'true_bits_weighted':float(np.average(p.true_bits,weights=p.tokens)),
 'shuffle_both_mean_bits_weighted':float(np.average(p[['joint_shuffle_0_bits','joint_shuffle_1_bits','joint_shuffle_2_bits']].mean(axis=1),weights=p.tokens)),
 'shuffle_prev_mean_bits_weighted':float(np.average(p.prev_shuffle_bits,weights=p.tokens)),
 'shuffle_line_mean_bits_weighted':float(np.average(p.line_shuffle_bits,weights=p.tokens)),
 'folds_true_better_both':int((p.true_bits<p[['joint_shuffle_0_bits','joint_shuffle_1_bits','joint_shuffle_2_bits']].mean(axis=1)).sum()),
 'folds_true_better_prev':int((p.true_bits<p.prev_shuffle_bits).sum()),'folds_true_better_line':int((p.true_bits<p.line_shuffle_bits).sum())}
(ROOT/'context_placebo_summary.json').write_text(json.dumps(ss,indent=2))
print('SUMMARY',ss,flush=True)
