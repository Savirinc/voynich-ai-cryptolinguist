#!/usr/bin/env python3
"""Ablation: researcher-assigned Currier A/B labels as oracle side information.
All other 065 evaluation details unchanged.
"""
from pathlib import Path
import numpy as np,pandas as pd,json
script=Path(__file__).with_name('run_joint.py').read_text();base=script.split("models=['raw'")[0]
ns={'__name__':'voynich_currier_support','__file__':str(Path(__file__).with_name('run_joint.py'))}
exec(compile(base,str(Path(__file__).with_name('run_joint.py')),'exec'),ns)
raw=ns['raw']; LM=ns['LM'];ROOT=ns['ROOT']
rows=[]
for fold in range(5):
 train=raw[raw.fold!=fold].copy();test=raw[raw.fold==fold].copy()
 for mode in ['style','layout','context']:
  l=LM(train.itertuples(index=False),mode)
  bits=sum(l.score(r) for r in test.itertuples(index=False))/len(test)
  train['variety']='?';test['variety']='?'
  ln=LM(train.itertuples(index=False),mode)
  bits_novar=sum(ln.score(r) for r in test.itertuples(index=False))/len(test)
  rows.append({'fold':fold,'model':mode,'n':len(test),'bits_known_currier':bits,'bits_without_currier':bits_novar})
  print(fold,mode,round(bits,5),round(bits_novar,5),flush=True)
  # reset values each iteration so next mode uses true Currier labels
  train['variety']=raw.loc[train.index,'variety'];test['variety']=raw.loc[test.index,'variety']
p=pd.DataFrame(rows);p.to_csv(ROOT/'currier_ablation.csv',index=False)
r={}
for mode,g in p.groupby('model'):
 r[mode]={'bits_with_researcher_currier':float(np.average(g.bits_known_currier,weights=g.n)),
 'bits_without_currier':float(np.average(g.bits_without_currier,weights=g.n)),
 'folds_researcher_currier_improved':int(sum(g.bits_known_currier<g.bits_without_currier))}
(ROOT/'currier_ablation_summary.json').write_text(json.dumps(r,indent=2));print(r)
