from pathlib import Path
import json, pandas as pd, numpy as np
from collections import Counter
from itertools import combinations
ROOT=Path('/mnt/data')
p=ROOT/'voynich_zodiac_slot_map.csv';d=pd.read_csv(p)
c=d[d.folio=='f72r3'].sort_values('transcription_order').copy().reset_index(drop=True)
pt=[7,9,8,7,8,8,None,7,7,None,8,7,9,7,7,None,8,None,9,8,8,None,7,9,7,8,10,7,7,7]
print('Cancer original manual counts',Counter(pt))
assert len(pt)==len(c)==30
assert Counter(v for v in pt if v is not None)==Counter({7:12,8:8,9:4,10:1})
c['star_points']=pt;c['label']=c.voynich_label.astype(str);c['clean']=c.label.str.fullmatch('[a-z]+').fillna(False)
c[['folio','ring','transcription_order','clock_position','label','star_points','clean']].to_csv(ROOT/'voynich_067_cancer_coded_attributes.csv',index=False)
exec(open(ROOT/'voynich_067_pisces_test.py').read().split('rng=np.random.default_rng')[0].split('rng=np.random.default_rng')[0].split("print('usable'")[0].replace("assert Counter(points)==Counter({7:15,6:11,8:3})", "assert Counter(points)==Counter({7:15,6:11,8:3})")) if False else None

def sim(a,b):
 aa=Counter(a[i:i+2] for i in range(len(a)-1));bb=Counter(b[i:i+2] for i in range(len(b)-1));return 2*sum((aa&bb).values())/(sum(aa.values())+sum(bb.values()))

def score(x,attr='star_points'):
 same=[];diff=[]
 for ring in x.ring.unique():
  z=x[x.ring==ring]
  for a,b in combinations(z.itertuples(index=False),2):
   (same if getattr(a,attr)==getattr(b,attr) else diff).append(sim(a.label,b.label))
 return np.mean(same)-np.mean(diff),len(same),len(diff)

random=np.random.default_rng(702)
results={}
for sign in ['Pisces','Cancer']:
 x=(pd.read_csv(ROOT/('voynich_067_pisces_coded_attributes.csv' if sign=='Pisces' else 'voynich_067_cancer_coded_attributes.csv')))
 x=x[x.clean & x.star_points.notna()].copy()
 x['star_points']=x.star_points.astype(int)
 obs,ns,nd=score(x)
 perms=[];cycles=[]
 for i in range(3000):
  z=x.copy()
  for ring in z.ring.unique():
   ind=z[z.ring==ring].index
   vs=z.loc[ind,'star_points'].to_numpy()
   z.loc[ind,'star_points']=random.permutation(vs) if i<1500 else np.roll(vs,random.integers(0,len(vs)))
  (perms if i<1500 else cycles).append(score(z)[0])
 results[sign]={'n_clean':len(x),'star_points_distribution':dict(Counter(map(int,x.star_points))),'observed_bigram_similarity_difference':float(obs),'same_pairs':ns,'different_pairs':nd,'shuffle_p_one_sided':(sum(v>=obs for v in perms)+1)/(len(perms)+1),'cyclic_p_one_sided':(sum(v>=obs for v in cycles)+1)/(len(cycles)+1)}
print(json.dumps(results,indent=2))
(ROOT/'voynich_067_two_signs_results.json').write_text(json.dumps(results,indent=2))
