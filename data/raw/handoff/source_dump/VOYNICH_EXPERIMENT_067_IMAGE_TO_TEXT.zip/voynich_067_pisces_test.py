from __future__ import annotations
import pandas as pd, numpy as np, json, math
from itertools import combinations
from collections import Counter
from pathlib import Path
ROOT=Path('/mnt/data')
d=pd.read_csv(ROOT/'voynich_zodiac_slot_map.csv');d=d[d.folio=='f70v2'].sort_values('transcription_order').copy().reset_index(drop=True)
# Points and blue heads from the independently compiled 299-figure manual catalogue.
# Publicly viewable data: https://end.rito.one/solved/data/all_299_figures.json
points=[7,7,6,6,7,7,6,7,7,6,6,6,6,7,7,7,7,8,7,8,6,6,7,6,6,8,7,7,7]
blue_indices=[7,9,10,11,12,13,26] # blue/blue-gray heads incl inner figure 26
assert len(points)==len(d)==29
assert Counter(points)==Counter({7:15,6:11,8:3})
d['star_points']=points
d['blue_on_head']=[int(k in blue_indices) for k in range(1,30)]
d['label']=d.voynich_label.astype(str)
d['clean']=d.label.str.fullmatch('[a-z]+').fillna(False)
# Only pure unambiguous single words, no markers, brackets or inferred splitting.
D=d[d.clean].copy()
print('usable',len(D),'per ring',D.ring.value_counts().to_dict(),'point counts',D.star_points.value_counts().to_dict())

def sim(a,b):
    # adjacent bigram dice, plus unigram overlap, avoiding shared initial 'o' dominating
    aa=Counter(a[i:i+2] for i in range(len(a)-1));bb=Counter(b[i:i+2] for i in range(len(b)-1))
    den=sum(aa.values())+sum(bb.values());return 2*sum((aa&bb).values())/den if den else 0.0

def score(X, attr):
    within=[];between=[]
    for r in ['outer','inner']:
        x=X[X.ring==r]
        for a,b in combinations(x.itertuples(index=False),2):
            v=sim(a.label,b.label)
            if getattr(a,attr)==getattr(b,attr): within.append(v)
            else: between.append(v)
    return (np.mean(within)-np.mean(between)) if within and between else np.nan, len(within),len(between)

rng=np.random.default_rng(714)
res={}
for attr in ['star_points','blue_on_head']:
    obs,n_same,n_diff=score(D,attr)
    null=[];cyc=[]
    for i in range(3000):
        z=D.copy()
        for ring in ['outer','inner']:
            ind=z[z.ring==ring].index
            if i < 1500:
                z.loc[ind,attr]=rng.permutation(z.loc[ind,attr].to_numpy())
            else:
                z.loc[ind,attr]=np.roll(z.loc[ind,attr].to_numpy(), rng.integers(0,len(ind)))
        (null if i<1500 else cyc).append(score(z,attr)[0])
    null=np.array(null);cyc=np.array(cyc)
    res[attr]={'obs_same_minus_different':float(obs),'same_pairs':n_same,'different_pairs':n_diff,'permutation_p_one_sided':float((np.sum(null>=obs)+1)/(len(null)+1)),'cyclic_shift_p_one_sided':float((np.sum(cyc>=obs)+1)/(len(cyc)+1)),'null_mean':float(null.mean()),'cyclic_null_mean':float(cyc.mean())}
print(json.dumps(res,indent=2))
d[['folio','ring','transcription_order','clock_position','label','star_points','blue_on_head','clean']].to_csv(ROOT/'voynich_067_pisces_coded_attributes.csv',index=False)
(ROOT/'voynich_067_pisces_results.json').write_text(json.dumps({'data_source':'third-party hand-coded images; labels cross-referenced against supplied IVTFF','test':'Within-ring bigram Dice similarity; same-feature vs different-feature; per-ring label shuffles and cyclic shifts','features':res},indent=2))
