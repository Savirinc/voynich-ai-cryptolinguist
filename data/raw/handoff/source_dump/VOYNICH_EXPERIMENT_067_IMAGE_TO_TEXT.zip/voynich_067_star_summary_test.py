from __future__ import annotations
import json
import numpy as np
import pandas as pd
from collections import Counter
from pathlib import Path
P=Path('/mnt/data')
# Independently-coded secondary catalogue, https://end.rito.one/solved/figures.html
rows=[
('Pisces',29,{6:11,7:15,8:3}),
('Aries',30,{5:2,6:4,7:23,8:1}),
('Taurus',30,{7:20,8:7,9:3}),
('Gemini',30,{6:4,7:9,8:11}),
('Cancer',30,{7:12,8:8,9:4,10:1}),
('Leo',30,{7:3,8:9,9:7,10:2,11:1}),
('Virgo',30,{7:3,8:22}),
('Libra',30,{6:2,7:12,8:13,9:3}),
('Scorpio',30,{6:3,7:14,8:13}),
('Sagittarius',30,{6:1,7:3,8:14,9:7,10:2})]
rec=[];groups=[]
for name,figs,pts in rows:
 n=sum(pts.values()); rec.append({'sign':name,'figures':figs,'counted_stars':n,'uncounted':figs-n,'mean_points':sum(k*v for k,v in pts.items())/n,**{f'points_{k}':pts.get(k,0) for k in range(5,12)}})
 groups.append(np.repeat(np.array(list(pts.keys()),dtype=int),list(pts.values())))
S=pd.DataFrame(rec);S.to_csv(P/'voynich_067_star_count_by_sign.csv',index=False)
# Randomization test for sign-specific star point count, assuming all counted stars share one distribution
allpts=np.concatenate(groups);sizes=[len(g) for g in groups]
mean=allpts.mean(); between=sum(n*(g.mean()-mean)**2 for n,g in zip(sizes,groups)); within=sum(((g-g.mean())**2).sum() for g in groups)
F=(between/9)/(within/(len(allpts)-10))
perm=30000;rng=np.random.default_rng(167);hits=0
for _ in range(perm):
 r=rng.permutation(allpts);start=0;bw=0;ww=0
 for n in sizes:
  vals=r[start:start+n];start+=n;mw=vals.mean();bw+=n*(mw-mean)**2;ww+=((vals-mw)**2).sum()
 stat=(bw/9)/(ww/(len(allpts)-10)); hits+=(stat>=F)
res={'analysis':'unverified manual catalogue; 10 sign-level bins (12 panels combined); within-sign star point count','number_of_counted_stars':len(allpts),'F_between_within':F,'permutation_runs':perm,'upper_tail_p':(hits+1)/(perm+1),'max_min_mean_point_gap':float(max(S.mean_points)-min(S.mean_points)), 'mean_by_sign':{str(r.sign):round(float(r.mean_points),3) for r in S.itertuples()}}
(P/'voynich_067_visual_heterogeneity.json').write_text(json.dumps(res,indent=2))
print(S[['sign','figures','counted_stars','uncounted','mean_points']].to_string(index=False))
print(json.dumps(res,indent=2))
