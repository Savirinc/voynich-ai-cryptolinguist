#!/usr/bin/env python3
"""Experiment 066: context specificity and zodiac-sign panel lexical coherence.
Ground truth EVA from conservative 064 corpus. This does NOT decode any word.
Reproducible deterministic tests, physical leaf held out for q experiment.
"""
import json, hashlib, math, collections
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.spatial.distance import jensenshannon
from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss,roc_auc_score
ROOT=Path('/mnt/data');OUT=ROOT/'voynich_066';OUT.mkdir(exist_ok=True)
df=pd.read_csv(ROOT/'voynich_tournament_064/indexed_clean_corpus.csv',keep_default_na=False,dtype={'folio':str,'leaf':str,'EVA':str})
df=df[df.EVA.str.fullmatch('[a-z]{2,20}')].reset_index(drop=True)
# Token context inside same line only. Some gaps in parsing are maintained via token-index adjacency.
P=df[df['mode']=='prose'].copy().reset_index(drop=True)
records=[]
for (folio,line),g in P.groupby(['folio','line_id'],sort=False):
    rows=list(g.itertuples(index=False))
    for j,r in enumerate(rows):
        w=r.EVA
        if not (w.startswith('qo') or w.startswith('o')): continue
        stem=w[1:] if w.startswith('q') else w
        prev=rows[j-1] if j else None
        prevword=prev.EVA if prev is not None and prev.token_index_in_line+1==r.token_index_in_line else ''
        prev2=rows[j-2] if j>1 else None
        prev2word=prev2.EVA if prev2 is not None and prev is not None and prev2.token_index_in_line+1==prev.token_index_in_line and prevword else ''
        records.append(dict(leaf=str(r.leaf),folio=r.folio,section=r.section,hand=str(r.hand),currier=r.Currier if r.Currier in ('A','B') else '?',stem=stem,target=int(w.startswith('q')),prev=prevword,prev2=prev2word,
                         linepos=min(int(r.token_index_in_line),12),end=int(r.is_last_term)))
Q=pd.DataFrame(records)
# Restrict to stems that can be both q and non-q in full corpus (exploratory vocabulary eligibility but no labels leaked into fit)
both=Q.groupby('stem').target.agg(['min','max']); paired=set(both.index[(both['min']==0)&(both['max']==1)])
Q=Q[Q.stem.isin(paired) & Q.prev.ne('')].copy().reset_index(drop=True)
Q['fold']=Q.leaf.map(lambda s:int(hashlib.sha256(('v066:'+s).encode()).hexdigest()[:8],16)%5)
def feats(r, level):
 s=r.stem;d={'stem_exact='+s:1,'stem_beg='+s[:3]:1,'stem_end='+s[-3:]:1,'currier='+r.currier:1,'section='+r.section:1, 'end='+str(r.end):1,
            'linepos='+str(min(6,r.linepos//2)):1}
 if level>=1:
  d['prev_last1='+r.prev[-1:]]=1
 if level>=2:
  d['prev_last2='+r.prev[-2:]]=1
 if level>=3:
  d['prev_word='+r.prev]=1
 if level>=4:
  d['prev2_last='+r.prev2[-1:]]=1
 return d
CV=[];perword=[]
for fold in sorted(Q.fold.unique()):
 train=Q[Q.fold!=fold]; test=Q[Q.fold==fold]
 if not len(test):continue
 for level in range(5):
  v=DictVectorizer();X=v.fit_transform([feats(r,level) for r in train.itertuples(index=False)]);Y=v.transform([feats(r,level) for r in test.itertuples(index=False)])
  clf=LogisticRegression(C=0.5,solver='liblinear',max_iter=180,random_state=66)
  clf.fit(X,train.target.to_numpy()); pp=np.clip(clf.predict_proba(Y)[:,1],1e-7,1-1e-7); y=test.target.to_numpy()
  CV.append({'fold':int(fold),'level':level,'n_test':len(test),'logloss_nats':float(log_loss(y,pp)),'auc':float(roc_auc_score(y,pp)) if len(set(y))>1 else None})
  for leaf,actual,pred in zip(test.leaf,y,pp):
   perword.append((int(fold),level,str(leaf),float(-actual*np.log(pred)-(1-actual)*np.log(1-pred))))
S=pd.DataFrame(CV);S.to_csv(OUT/'q_context_cv.csv',index=False)
agg=S.groupby('level').apply(lambda x:float(np.average(x.logloss_nats,weights=x.n_test)),include_groups=False).to_dict()
D=pd.DataFrame(perword,columns=['fold','level','leaf','loss']);delta=(D[D.level==1].groupby('leaf').loss.sum()-D[D.level==3].groupby('leaf').loss.sum())/D[D.level==1].groupby('leaf').size();
# cluster bootstrap by physical leaf, using equal leaf sample weights expressed per token
keys=np.array(sorted(delta.index)); c1=D[D.level==1].groupby('leaf').loss.sum();c3=D[D.level==3].groupby('leaf').loss.sum(); ct=D[D.level==1].groupby('leaf').size(); rng=np.random.default_rng(66); boots=[]
for _ in range(1000):
 ids=rng.choice(keys,size=len(keys),replace=True); boots.append(float((c1.loc[ids].sum()-c3.loc[ids].sum())/ct.loc[ids].sum()))
# zodiac panels: test distinctive signatures for paired Aries/Taurus. Use LABELS only and common prefixes (EVA transcribed).
labels=df[(df['mode']=='label') & df.folio.isin(['f70v2','f70v1','f71r','f71v','f72r1','f72r2','f72r3','f72v3','f72v2','f72v1','f73r','f73v'])].copy()
# Note folio f72r1 is Taurus, f71v Taurus; Aries f70v1/f71r.
panels={p:list(g.EVA) for p,g in labels.groupby('folio')};names=sorted(panels)
# text ngram distribution; 2- and 3-glyph prefixes; smoothing with global empirical prior
all_features=collections.Counter(); panelfeatures={}
for p,ws in panels.items():
 c=collections.Counter(('p2',w[:2]) for w in ws)
 c.update(('p3',w[:3]) for w in ws)
 panelfeatures[p]=c;all_features.update(c)
feat=sorted(all_features);globaldist=np.array([all_features[f] for f in feat],float);globaldist/=globaldist.sum()
Pvec={}
for p,c in panelfeatures.items():
 a=np.array([c[f] for f in feat],float); a+=1.2*globaldist;Pvec[p]=a/a.sum()
pair=[]
for a in names:
 for b in names:
  if a>=b:continue
  js=float(jensenshannon(Pvec[a],Pvec[b],base=2)**2)
  pair.append(dict(a=a,b=b,divergence_bits=js, same_sign=((set([a,b])=={'f70v1','f71r'}) or (set([a,b])=={'f71v','f72r1'}))))
pairs=pd.DataFrame(pair).sort_values('divergence_bits');pairs.to_csv(OUT/'zodiac_panel_distances.csv',index=False)
actual=(pairs[pairs.same_sign].divergence_bits.mean()); rank=[]
for _,r in pairs[pairs.same_sign].iterrows(): rank.append({'a':r.a,'b':r.b,'distance':r.divergence_bits,'rank_closest':int((pairs.divergence_bits<r.divergence_bits).sum())+1,'total_pairs':len(pairs)})
# Entire pairs null: compare 2 arbitrarily chosen independent pairs among all 12 panels: 12C4*3=1485.
vals=[]
for i,a in enumerate(names):
 for b in names[i+1:]:
  remaining=[s for s in names if s not in (a,b)]
  for j,c in enumerate(remaining):
   for d in remaining[j+1:]:
    if (a,b)>(c,d):continue
    z=(float(pairs[((pairs.a==a)&(pairs.b==b))].divergence_bits.iloc[0])+float(pairs[((pairs.a==c)&(pairs.b==d))].divergence_bits.iloc[0]))/2
    vals.append(z)
vals=np.array(vals);p=float((1+(vals<=actual).sum())/(len(vals)+1))
report={'experiment':66,'corpus':{'clean_tokens':len(df),'q_compared':len(Q),'folios':int(Q.leaf.nunique()),'zodiac_panels':len(panels),'zodiac_label_tokens':len(labels)},
        'q_context':{'description':['stem and section','+ previous final 1','+ previous final 2','+ full previous word','+ word before previous final 1'],
                     'weighted_heldout_logloss_nats':agg,'five_fold':CV,'improvement_level1_to3_95pct_clusterbootstrap':list(np.quantile(boots,[.025,.975])),'improvement_level1_to3_mean':float(np.mean(boots))},
        'zodiac':{'panel_pair_ranks':rank,'observed_same_sign_mean_JS_bits':float(actual),'all_pair_null_mean_JS_bits':float(vals.mean()),'exact_pair_randomization_p_lower_is_more_similar':p,'null_n':len(vals),
                  'warning':'Uncertain true ring start/orientation; smaller panels and sample imbalance; lexical identity expected only if labels encode sign-specific features rather than individual zodiac degrees.'},
        'disclaimer':'No decipherment; lexical panel test conditional on visual sign matching; candidate language corpora absent.'}
(OUT/'results.json').write_text(json.dumps(report,indent=2));print(json.dumps({'q_scores':agg,'q_cluster_interval':report['q_context']['improvement_level1_to3_95pct_clusterbootstrap'],'zodiac':report['zodiac'],'tokens':report['corpus']},indent=2))
