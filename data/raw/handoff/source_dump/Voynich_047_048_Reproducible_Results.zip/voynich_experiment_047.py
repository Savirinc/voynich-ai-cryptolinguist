"""Voynich 047: identify which preceding-word features predict q-attachment.
Source: local ZL v3b Eva 2025 transcription, using same folio-held-out split as 044/046.
"""
from docx import Document
from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss,roc_auc_score
from collections import Counter,defaultdict
import re,random,json,numpy as np
from pathlib import Path
D=Path('/mnt/data');P=Document(D/'IVTFF Eva.txt.docx').paragraphs
rows=[];lang={}
for p in P:
 t=p.text.strip(); m0=re.match(r'<(f\d+[rv])>.*?\$L=([AB])',t)
 if m0:lang[m0.group(1)]=m0.group(2)
 m=re.match(r'<(f\d+[rv])\.(\d+)[^>]*>\s*(.*)',t)
 if not m:continue
 fol=m.group(1);ws=[w for w in re.split(r'[., ]+',m.group(3).split('<!')[0]) if re.fullmatch(r'[a-z]{2,20}',w)]
 for i,w in enumerate(ws):
  if w.startswith('qo') or (w.startswith('o') and len(w)>2):
   stem=w[1:] if w.startswith('qo') else w
   if len(stem)<3:continue
   rows.append((fol,stem,int(w.startswith('q')),ws[i-1] if i else '<BOS>',ws[i+1] if i+1<len(ws) else '<EOS>',lang.get(fol,'?')))
folios=sorted(set(r[0] for r in rows));random.Random(20261012).shuffle(folios);test=set(folios[::5]);train=[r for r in rows if r[0] not in test];held=[r for r in rows if r[0] in test]
def feat(r,add):
 _,s,y,p,n,k=r;d={'stem='+s:1,'s_begin='+s[:2]:1,'s_end='+s[-2:]:1,'kind='+k:1}
 if 'last1' in add:d['prev_last1='+p[-1:]]=1
 if 'last2' in add:d['prev_last2='+p[-2:]]=1
 if 'first1' in add:d['prev_first1='+p[:1]]=1
 if 'first2' in add:d['prev_first2='+p[:2]]=1
 if 'length' in add:d['prev_length='+str(min(len(p),12))]=1
 if 'whole' in add:d['prev='+p]=1
 return d
def model(a):
 dv=DictVectorizer();X=dv.fit_transform([feat(r,a) for r in train]);T=dv.transform([feat(r,a) for r in held]);ys=[r[2] for r in train];yh=[r[2] for r in held];clf=LogisticRegression(C=.5,solver='liblinear').fit(X,ys);ps=clf.predict_proba(T)[:,1]
 return {'loss':round(float(log_loss(yh,ps)),5),'auc':round(float(roc_auc_score(yh,ps)),5),'nfeatures':len(dv.vocabulary_)},(clf,dv)
sets={'stem_section':[], 'prev_last1':['last1'],'prev_last2':['last2'],'prev_first1':['first1'],'prev_first2':['first2'],'prev_length':['length'],'prev_last2_first2':['last2','first2'],'prev_all_shapes':['last1','last2','first1','first2','length'],'prev_all_shapes_plus_word':['last1','last2','first1','first2','length','whole']}
results={};mods={}
for k,v in sets.items():results[k],mods[k]=model(v)
# raw prev last 1 & 2 distribution, train/test split
byend=defaultdict(Counter)
for fol,s,q,prev,n,kind in rows: byend[(prev[-1:] if prev not in ['<BOS>','<EOS>'] else 'BOS',kind)][q]+=1
summary=[]
for (ending,kind),ct in byend.items():
 if sum(ct.values())>=70:summary.append((kind,ending,sum(ct.values()),round(ct[1]/sum(ct.values()),4)))
# summary by end on whole and held-out
raw=[]
for subset,name in [(rows,'all'),(held,'heldout')]:
 c=defaultdict(Counter)
 for _,s,q,p,n,k in subset:
  en=p[-1:] if p not in ['<BOS>','<EOS>'] else 'BOS';c[en][q]+=1
 raw.append((name,sorted([(k,sum(v.values()),round(v[1]/sum(v.values()),4)) for k,v in c.items() if sum(v.values())>=25],key=lambda x:-x[1])))
# Import coefficients of morphological ending
clf,dv=mods['prev_last1']; co=clf.coef_[0]
coef=sorted([(key,round(float(co[idx]),3)) for key,idx in dv.vocabulary_.items() if key.startswith('prev_last1=')],key=lambda x:x[1],reverse=True)
# take 10 most influential preceding bigrams
clf,dv=mods['prev_last2'];co=clf.coef_[0]
end2=sorted([(key,round(float(co[idx]),3)) for key,idx in dv.vocabulary_.items() if key.startswith('prev_last2=')],key=lambda x:x[1],reverse=True)
out={'data':{'all':len(rows),'test':len(held),'heldout_folios':len(test)},'ablation':results,'raw_endings':dict(raw),'ending_by_currier':sorted(summary,key=lambda x:(x[0],-x[2])),'adjusted_last1_coefficients':coef,'most_positive_last2_coefficients':end2[:12],'most_negative_last2_coefficients':end2[-12:]}
(D/'voynich_experiment_047_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
