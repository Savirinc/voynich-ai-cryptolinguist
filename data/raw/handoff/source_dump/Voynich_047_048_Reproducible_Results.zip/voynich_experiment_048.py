"""Experiment 048: Does previous ending -y predict the qo-/o- alternation,
control for stem/Currier variety, and generalize across folios?
ZL/IVTFF transcription, via user-provided DOCX.
Only statistical associations are investigated. No translation claimed.
"""
from pathlib import Path
import re,random,json,collections
import numpy as np
from docx import Document
from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss,roc_auc_score
from statsmodels.stats.contingency_tables import StratifiedTable

DATA=Path('/mnt/data'); raws=Document(DATA/'IVTFF Eva.txt.docx').paragraphs
lang={}; rows=[]
for p in raws:
    t=p.text.strip()
    hd=re.match(r'^<(f\d+[rv])>\s*<!.*?\$L=([AB])',t,re.I)
    if hd: lang[hd.group(1).lower()]=hd.group(2)
    m=re.match(r'^<(f\d+[rv])\.(\d+)[^>]*>\s*(.*)',t,re.I)
    if not m: continue
    fol=m.group(1).lower()
    ws=[w for w in re.split(r'[., ]+',m.group(3).split('<!')[0]) if re.fullmatch(r'[a-z]{2,20}',w)]
    for i,w in enumerate(ws):
        if not (w.startswith('qo') or (w.startswith('o') and len(w)>2)): continue
        stem=w[1:] if w.startswith('qo') else w
        if len(stem)<3:continue
        prev=ws[i-1] if i else ''
        rows.append({'folio':fol,'kind':lang.get(fol,'?'),'stem':stem,'q':int(w.startswith('q')),
                     'prev':prev,'prev_y':int(prev.endswith('y')) if prev else 0,'prev_terminal':prev[-1:] if prev else 'BOS'})
folios=sorted({x['folio'] for x in rows});random.Random(20261012).shuffle(folios);test=set(folios[::5])
train=[r for r in rows if r['folio'] not in test];held=[r for r in rows if r['folio'] in test]

def ft(r,mode):
    s=r['stem'];d={'s='+s:1,'s_start='+s[:2]:1,'s_end='+s[-2:]:1,'sec='+r['kind']:1}
    if mode=='y':d['prev_y='+str(r['prev_y'])]=1
    if mode=='last1':d['last='+r['prev_terminal']]=1
    return d

def fit(mode):
    dv=DictVectorizer();X=dv.fit_transform([ft(r,mode) for r in train]);T=dv.transform([ft(r,mode) for r in held]);y=np.array([r['q'] for r in train]);yt=np.array([r['q'] for r in held]);clf=LogisticRegression(C=.5,solver='liblinear',max_iter=350).fit(X,y);prob=clf.predict_proba(T)[:,1]
    return {'logloss':round(float(log_loss(yt,prob)),6),'auc':round(float(roc_auc_score(yt,prob)),5),'nfeatures':len(dv.vocabulary_)},prob
metrics={};probs={}
for mode in ['base','y','last1']:
    metrics[mode],probs[mode]=fit(mode)

# Folio-bootstrap CI for held-out difference in per-example logloss improvement (base minus model)
ys=np.array([r['q'] for r in held]); idx={f:np.array([i for i,r in enumerate(held) if r['folio']==f]) for f in sorted(test)}
eps=1e-12
sampleloss=lambda p:-(ys*np.log(np.maximum(p,eps))+(1-ys)*np.log(np.maximum(1-p,eps)))
baseL=sampleloss(probs['base']);yL=sampleloss(probs['y']);l1L=sampleloss(probs['last1'])
fols=list(idx);rng=np.random.default_rng(20261012)
bt=[]
for _ in range(3000):
    chosen=rng.choice(fols,size=len(fols),replace=True)
    indices=np.concatenate([idx[k] for k in chosen])
    bt.append([float(np.mean(baseL[indices]-yL[indices])),float(np.mean(baseL[indices]-l1L[indices]))])
bt=np.array(bt)
bootstrap={'y_gain_mean':round(float(np.mean(baseL-yL)),6),'y_gain_95pct':np.quantile(bt[:,0],[.025,.975]).round(6).tolist(),
           'last1_gain_mean':round(float(np.mean(baseL-l1L)),6),'last1_gain_95pct':np.quantile(bt[:,1],[.025,.975]).round(6).tolist(),
           'y_folios_gain':int(sum(np.mean(baseL[idx[f]]-yL[idx[f]])>0 for f in fols)),
           'last1_folios_gain':int(sum(np.mean(baseL[idx[f]]-l1L[idx[f]])>0 for f in fols))}

# CMH conditional odds ratios, stratify by stem and section (this controls confounding from stem and Currier variety).
def cmh(sub):
    c=collections.defaultdict(lambda:np.zeros((2,2),dtype=int))
    for r in sub:
        if not r['prev']:continue # Exclude line starts
        c[(r['stem'],r['kind'])][r['prev_y'],r['q']]+=1
    tab=[];n=0
    for v in c.values():
        if v[0].sum()>0 and v[1].sum()>0 and v[:,0].sum()>0 and v[:,1].sum()>0:
            tab.append(v);n+=int(v.sum())
    if not tab:return None
    st=StratifiedTable(tab)
    return {'strata':len(tab),'observations_in_informative_strata':n,'common_odds_ratio':round(float(st.oddsratio_pooled),4),
            'odds_ratio_95pct':np.round(st.oddsratio_pooled_confint(),4).tolist(),
            'null_odds_ratio_pvalue':round(float(st.test_null_odds().pvalue),8)}

# Raw rates by endings, overall + within section, with no start-of-line records
rates={}
for name,sub in [('all',rows),('train',train),('heldout',held),('CurrierA',[r for r in rows if r['kind']=='A']),('CurrierB',[r for r in rows if r['kind']=='B'])]:
    c=collections.defaultdict(lambda:[0,0])
    for r in sub:
        if not r['prev']:continue
        k=r['prev_terminal'];c[k][0]+=1;c[k][1]+=r['q']
    rates[name]=sorted([{'prev_ends':k,'n':v[0],'q_rate':round(v[1]/v[0],5)} for k,v in c.items() if v[0]>=25],key=lambda d:-d['n'])[:12]

out={'description':'Previous terminal marker as predictor of qo/o forms (no decoding of meaning)',
     'n_rows':len(rows),'train':len(train),'heldout':len(held),'heldout_folios':len(test),
     'models':metrics,'folio_cluster_bootstrap':bootstrap,
     'cmh_control_for_stem_and_currier_all':cmh(rows),
     'cmh_control_for_stem_and_currier_heldout':cmh(held),
     'cmh_within_Currier_A':cmh([r for r in rows if r['kind']=='A']),
     'cmh_within_Currier_B':cmh([r for r in rows if r['kind']=='B']),
     'cmh_heldout_A':cmh([r for r in held if r['kind']=='A']),
     'cmh_heldout_B':cmh([r for r in held if r['kind']=='B']),
     'rates':rates,
     'limitations':['Selected only tokens starting qo or o; results do not apply to every following word.',
                    'EVA glyph transcription is not phonetic transcription.',
                    'Visual scribal evidence and French/Latin controls not included.',
                    'Some cases may be affected by delimiter / transcription ambiguities.']}
(DATA/'voynich_experiment_048_results.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
