from pathlib import Path
import json, pandas as pd, csv, zipfile, hashlib, textwrap
O=Path('/mnt/data/voynich_tournament_064'); R=json.loads((O/'results.json').read_text());Z=json.loads((O/'zodiac_position_stronger_controls.json').read_text());L=json.loads((O/'label_prose_register_control.json').read_text())
H=[
('H01','Position-constrained glyphs','SUPPORTED (structural)','q overwhelmingly begins words; n/m overwhelmingly end them; i predominantly internal','Specific phonetic values or allography','Verify scan-level stroke segmentation and other transcriptions'),
('H02','q plus o is a special unit','OPEN','Initial q is followed by o ~98%','Single grapheme, prefix, negation, plural, cipher marker','Physical glyph audit; test reversible q/o vs independent letter models'),
('H03','q marks negation','NO SEMANTIC SUPPORT','Forms o... / qo... coexist','They mean opposites','Require identified negative/positive contrast from external semantics'),
('H04','q marks plurality/case/tense','NO SEMANTIC SUPPORT','q conditioned by preceding glyph','Which grammatical function it encodes','Find independently identified referents differing in number/inflection'),
('H05','q written form depends on preceding word','SUPPORTED (predictive)','CV log loss improves when including preceding word ending','Causal rule rather than normal syntactic context','Counterfactual with stronger language controls'),
('H06','m is positional letterform/abbreviation','SUPPORTED (position only)','Line-end improves m vs iin prediction','m and iin have equal meaning or sound','Blind high-resolution glyph form clusters; compare word families'),
('H07','m = iin universally','WEAKENED','Stem pairs common, but earlier placebo m-pair mergers were comparably predictive','Literal universal equivalence','Distinct heldout morphological identity test'),
('H08','Minim groups in/iin are one unit','INCONCLUSIVE','Common glyph groups, Currier transcribes as units','Actual indivisible symbol or sound','Independent pen stroke traces and model with adequate context'),
('H09','Benched ch/sh groups are useful units','SUPPORTED (predictive only)','Two-context LM gains on unseen leaves with bench segmentation','Phoneme or glyph identity','Visual check and stronger neural context models'),
('H10','Currier A/B are different registers','SUPPORTED (distribution only)','Herbal-only prefix2 JS divergence exceeds folio randomization','Two distinct languages or ciphers','Compare matched scribes and same-topic bifolia'),
('H11','Zodiac labels are fixed 1–30 numerals','NOT SUPPORTED','30-position exploratory statistic fails familywise correction (~0.064)','Absence of degree labels','Derive reliable degree geometry from original scans; pre-register test'),
('H12','Zodiac labels contain sign/degree names','OPEN','30-ish illustrated units per sign, labels aligned with figures','Any original label translates to a name','Historical illustrated degree catalogues with blind holdout'),
('H13','Image attributes predict language units','NOT ESTABLISHED','Labels visually localized; prior barrel and plant-matching tests weak','Glosses for stars, jars, women, plants','Grounded colored-star/nymph inventory for 299 figures, blind predictor'),
('H14','Main script encodes Old French','OPEN: NOT SCORED','Later Roman alphabet annotations resemble medieval French','Main text speaks French','Date/genre-matched Old French corpus plus reversible cipher candidate'),
('H15','Main script encodes Latin/Occitan/German/Italian','OPEN: NOT SCORED','Historically plausible alternatives','Which if any language is present','Balanced historical text tournament under matched encoding model'),
('H16','Other languages / Persian / Arabic / East Asian','OPEN: NOT SCORED','No independent phonetic mappings; visual resemblance insufficient','Language/script origin','Comparative corpora and explicit falsifiable transcription mappings'),
('H17','Main text from simple monoalphabetic substitution','NOT ESTABLISHED','Naive crib otral = mars mismatches raw word length 5 vs 4','Any ciphertext/plaintext alignment is valid','Recover multiple independently verified cribs before testing substitution'),
('H18','Syllabic, shorthand or context transducer','OPEN, HIGH PRIORITY','Restricted glyph placement and reusable chunks are compatible','That any particular transducer translates real words','Minimum-description-length training with reversal and cross-folio heldout'),
('H19','Mechanical / non-semantic generator','OPEN','Structured statistics can emerge without semantics','That manuscript lacks information','Test multi-signature generative controls + independent visual semantics'),
('H20','Label prose have different grammatical register','SUPPORTED (distribution only)','q is ~1% of labels and ~16% prose; same-folio contrast survives','q grammatical function','Equivalent semantic units in prose vs captions under controlled contexts')]
cols=['id','hypothesis','status','corpus_evidence','does_not_prove','next_falsification_test']
pd.DataFrame(H,columns=cols).to_csv(O/'hypothesis_survival_matrix.csv',index=False)
source_list=[
('Old French / Picard / Anglo-Norman','Open Medieval French (Yvain, other critical editions)','https://github.com/OpenMedFr/texts','Texts c.12th–15th; many literary, some earlier than Voynich','NOT INGESTED','Match later French samples and medical/astrological genre'),
('Old French / Anglo-Norman','Base de français médiéval, Chanson de Roland','https://txm-bfm.huma-num.fr/txm/catalog/roland','Norman c.1100; 29,312 words; chronological mismatch','NOT INGESTED','Use as historical negative control, not 15th-century proxy'),
('Latin','CLTK/Perseus Latin texts','https://github.com/cltk/lat_text_perseus','Classical/late antique more than 15th-century; genre matters','NOT INGESTED','Find matching 14th/15th-century technical Latin'),
('Middle High German','BAdW Mittelhochdeutsch-Korpus','https://github.com/badw-dh/Mittelhochdeutsch-Korpus','1.1m annotated word forms from >100 texts','NOT INGESTED','Date and region align subset and preserve original orthography'),
('Old Occitan / Gascon','UD Old Occitan CorAG','https://github.com/UniversalDependencies/UD_Old_Occitan-CorAG','51k word forms incl. 1460 Bearn legal texts','NOT INGESTED','Select chronological/genre matches, strip linguistic annotation'),
('Old Occitan (handwriting)','CATMuS HTR Occitan','https://github.com/HTRogene/occitan','14th-century ground truth handwriting, relatively small','NOT INGESTED','Compare scribal ligatures, not alone language frequencies'),
('Persian/Arabic','Awaiting authentic era-matched sample','', 'Any Urdu/Farsi analogy concerns positional letter shapes not proven language identity','NOT INGESTED','Collect historical Persian/Arabic transliterations and run identical tests')]
pd.DataFrame(source_list,columns=['candidate','resource','url','qualification','current_data_status','selection_note']).to_csv(O/'historical_corpus_manifest.csv',index=False)
sg=pd.read_csv(O/'segmentation_crossvalidation.csv')
rows=[]
for k,frame in sg.groupby(['context','strategy']):
 raw=sg[(sg.context==k[0]) & (sg.strategy=='EVA_raw')].set_index('fold').bits_per_original_word
 f=frame.set_index('fold')
 rows.append({'context':k[0],'segmentation':k[1], 'bits_per_word':round((f.bits_per_original_word*f.test_count).sum()/f.test_count.sum(),5),
              'difference_vs_raw':round(((f.bits_per_original_word-raw)*f.test_count).sum()/f.test_count.sum(),5),
              'beats_raw_in_folds':int((f.bits_per_original_word<raw).sum())})
pd.DataFrame(rows).to_csv(O/'segmentation_summary.csv',index=False)
# Indexed corpus from source for reruns. Avoid extract entirely raw copied filenames, keep provenance and confidence.
from docx import Document
import re
meta={};tokens=[]
for p in Document('/mnt/data/IVTFF Eva.txt.docx').paragraphs:
 s=p.text.strip()
 h=re.match(r'^<(f\d+[rv]\d*)>\s*<!([^>]+)>',s)
 if h:
  f,raw=h.groups();meta[f]={}
  for tag,key in [('L','Currier'),('I','illustration'),('H','hand')]:
   a=re.search(r'\$'+tag+r'=([^\s$>]+)',raw);meta[f][key]=a.group(1) if a else '?'
 m=re.match(r'^<(f\d+[rv]\d*)\.(\d+),([^>]+)>\s*(.*)',s)
 if not m:continue
 f,num,loc,raw=m.groups();mode='prose' if 'P' in loc else 'label' if 'L' in loc else 'circle' if 'C' in loc else 'other'
 if mode not in ['prose','label']:continue
 raw=re.sub(r'<![^>]*>',' ',raw);raw=re.sub(r'<(?:%|\$|-)>','',raw)
 terms=[x for x in re.split('[.,\\s]+',raw) if x]
 for i,t in enumerate(terms):
  if not re.fullmatch('[a-z]{2,20}',t):continue
  tokens.append({'folio':f,'leaf':re.match(r'f(\d+)',f).group(1),'line_id':num,'locus':loc,'mode':mode,'token_index_in_line':i,
                 'EVA':t,'is_first_term':int(i==0),'is_last_term':int(i==len(terms)-1),
                 'Currier':meta.get(f,{}).get('Currier','?'),'section':meta.get(f,{}).get('illustration','?'),'hand':meta.get(f,{}).get('hand','?')})
pd.DataFrame(tokens).to_csv(O/'indexed_clean_corpus.csv',index=False)
print('INDEXED',len(tokens));

q=R['q_operator']; m=R['m_positional'];c=R['Currier_A_B'];l=R['labels_vs_prose'];strat=pd.read_csv(O/'segmentation_summary.csv')
fmt=lambda x:round(x,3)
report=f'''# Voynich Experiment 064: Simultaneous hypothesis tournament

**Status:** no lexical meaning, phonetic value, grammatical category, or complete translation established. The objective is to retain **reproducible structural constraints** while eliminating unsupported semantic assignments.

## Source and method

- Primary source: user's **ZL3b-n IVTFF EVA v3b, 13 May 2025** (`IVTFF Eva.txt.docx`), SHA-256 `{R['corpus']['source_sha256']}`.
- Full accessible transcription parsed; conservatively used **{R['corpus']['prose_tokens']:,}** clean paragraph tokens and **{R['corpus']['label_tokens']:,}** clean single-label tokens. Symbols marked as uncertain, rare/nonalphabetic and tokens with ambiguous spellings are excluded; totals therefore do not equal manuscript's total sign count.
- Five deterministic folds by physical **numbered leaf**, not individual word. This avoids training on the back of a leaf while testing its front. Folds are unbalanced in size; see results JSON.
- Predictive benchmarks score **original EVA words**, not merely normalized or shortened replacements. Candidate segmentations were pre-selected from earlier exploratory work, so the 'learned eight' list is not a clean externally held-out discovery.
- Zodiac uses **232 unambiguous single-token labels** with **provisional transcription-order positions**, not verified celestial degree order.

## Structural hypotheses that survive

| Test | Baseline loss | Added feature loss | Conclusion |
|---|---:|---:|---|
| q/no-q paired forms, stem + Currier | {q['stem+variety']['logloss']:.4f} | {q['+prev_final_exact']['logloss']:.4f} | Preceding word final glyph adds predictive information |
| m/iin paired forms, stem + Currier | {m['stem+variety']['logloss']:.4f} | {m['+line_end']['logloss']:.4f} | Line end strongly predicts `-m` form |

Log loss values are **natural units**, pooled out-of-fold predictions. They are NOT statements that q means negation or m means iin. `{q['+prev_final_exact']['auc']:.3f}` and `{m['+line_end']['auc']:.3f}` are the corresponding held-out AUCs.

### Glyph inventory and positions

- `{R['corpus']['prose_tokens']:,}` clean running tokens include `{R['corpus']['prose_types']:,}` surface word types; `{len(R['corpus']['glyph_1char_frequencies'])}` distinct EVA single characters occur, including very rare transcription variants. This is **not** the number of the author's underlying phonemes or letters.
- Initial `q`: {int(pd.read_csv(O/'glyph_position_table.csv').query("eva_symbol=='q'")['word_initial'].iloc[0]):,} glyph occurrences start a word out of 5,215 total q occurrences. `{L['q_initial_followed_o_rate']*100:.2f}%` of q-initial words have `o` as the next symbol.
- EVA `i` is overwhelmingly internal; `n` and `m` overwhelmingly final. See `glyph_position_table.csv` for full positional counts, not just the cherry-picked examples.
- Currier A and B remain different **among herbals only**: Jensen-Shannon divergence of initial two-character frequencies **{c['Herbal_A_B_JS_divergence_bits']:.4f} bits**, versus randomized-folio null mean **{c['randomized_folio_labels_mean']:.4f} bits**, p = **{c['randomized_folio_labels_p']:.4f}** over 400 exploratory permutations. This does not imply distinct languages.
- Isolated labels and prose have a strong register difference: only **{l['same_folio_label_q']}/{l['same_folio_labels']}** labels vs **{l['same_folio_prose_q']}/{l['same_folio_prose']}** prose tokens begin with q, counting only the **{l['common_folios_count']}** folios with both genres. Same-folio random allocation expects about **{L['random_reassignment_expected_label_q']:.1f}** q labels versus observed **{L['observed_label_q']}** (z = {L['zscore']:.2f}). That controls folio but not vocabulary/genre.

### Alphabet segmentation competition

Five-fold mean **original-word** costs, weighted by test count (bits per word):

{strat.to_markdown(index=False)}

Result: in a two-character context model, pre-selected `ch/sh` chunks help slightly, and eight preselected chunks help somewhat more. But a three-character-context model prefers **unmerged EVA across every fold**. This is evidence that some segmentation gains merely substitute for insufficient model memory. It does not identify true historical letter boundaries.

## Zodiac and proposed reading tests

**Provisional cyclic 5/7/10/15/30 slots** were tested for association with two-character label prefixes. Nulls preserve sign + ring membership; a second, stronger null only rotates whole rings, preserving adjacency. Familywise correction considers all five tested cycle lengths.

{pd.read_csv(O/'zodiac_position_stronger_controls.csv').to_markdown(index=False)}

The 30-position candidate scores **p ≈ 0.016** against uncorrected cyclic null but **familywise p ≈ 0.064**. That is weak exploratory evidence, **not** a decoded 1–30 count, especially since true zodiac-degree zero points remain unresolved. Previous ring-rotation tests also failed robust fixed numeric word identities.

**Proposed readings under challenge:**
- `otral = mars`: meaning not established; original sign/star label and later Roman-script month annotation are different objects. One-letter-one-letter substitution cannot directly map a five-EVA-symbol token to a four-letter French word without other rules, even if the referent were correct. The crib is **not admissible as a fixed truth**.
- `q = not`, `q = plural`, `q = preposition`, `q = contextual code`: all remain semantically indistinguishable from present evidence; only contextual spelling dependency survives.
- `-m = -iin`: matching stems and line-end association survive, but previous experiment 058 frequency-matched placebo merges did **not** validate identity (reported p≈0.43). Do not normalize mechanically.
- Month names such as `mars`, `aberil`, `may`, `jong` are in a distinguishable **later Latin-alphabet annotation**. Their dialect helps identify one manuscript reader, not necessarily the underlying Voynich language.

## Candidate languages: honest status

**No candidate language has won or been ruled out here.** Authenticated full medieval-language corpora were identified in the source manifest, but their full text could not be downloaded to the local analysis runtime. Directly comparing EVA letters to modern French or Latin letters would assume the unknown cipher key and produce unreliable rankings.

Candidate list: Old French (including Anglo-Norman, Picard), Latin, Old Occitan/Gascon, Middle High German, Middle Dutch, medieval northern Italian, Persian, Arabic, and other/hybrid/artificial systems. The competing *writing mechanisms* are even more important: literal substitution, syllabic/transducer, shorthand, positional allography, codebook, and non-semantic generator.

Historical comparison dataset targets with provenance, date and limitations are in `historical_corpus_manifest.csv`.

## Evidence decisions

- **Retain as structural regularities:** strongly position-restricted glyphs; q/qo transition, preceding-character effect, m end-of-line dependency, Currier A/B distribution differences, scarce q in figure labels.
- **Retain without decipherment claims:** hidden compound glyphs, allography, syllabic or context-dependent code, ordinary natural language with unknown spelling conventions, mechanical generation.
- **Weaken or reject as decoding shortcuts:** delete all q's; merge m/iin as proven synonyms; assume zodiac labels are fixed words for one through thirty; treat later `aberil` as a direct bilingual plaintext crib; declare a language because of glyph shape or exact EVA letters.
- **Potential near-signal:** 30-position prefix association did not pass five-test familywise correction. Pre-register geometry and exact statistic before retesting.

## The next decisive computational challenge (pre-registration)

1. Acquire and checksum **four separate historical-language corpora**. Match era and genre where possible. Hold language identities blind during cipher simulation. Test substitution, many-to-one, syllable, reversible context/transducer and a no-language generator with identical model-capacity constraints.
2. Compare exact original-word held-out log loss *and* a jointly calibrated signature of glyph placement, paragraph boundaries, line boundaries, repetition, A/B differences and label/prose differences. No single statistic may decide the winner.
3. Add independent glyph imaging in a blinded sample before choosing EVA ligature mappings.
4. Freeze ten unseen zodiac labels with verified geometry and an independently mapped medieval degree-image lexicon. **Only a successful semantic prediction** on those labels would count as approaching decipherment.

## Reproduction

`python run_tournament.py && python position_controls.py && python label_register_controls.py && python build_report.py`

Requirements: `python-docx`, `numpy`, `pandas`, `scipy`, `scikit-learn`, `tabulate`. Scripts expect user-provided corpus at `/mnt/data/IVTFF Eva.txt.docx`, with the two supplied zodiac CSVs also in `/mnt/data/`. The original source was not altered.

## Limitations

This is one EVA source, not an inter-transcriber consensus. Commas mark possible rather than certain word boundaries; strict tokenization may treat some disputed segments as words. All comparisons are exploratory and many hypotheses were historically suggested rather than fully specified. Statistical fit does not identify semantics or original phonemes. Local historical-language downloads did not succeed in this runtime. No high-resolution independent glyph segmentation was performed in this experiment.
'''
(O/'TOURNAMENT_REPORT.md').write_text(report,encoding='utf-8')
# Zip all new artifacts, include exact original DOCX for portable reproduction. Exclude temp/large earlier files.
with zipfile.ZipFile('/mnt/data/Voynich_Experiment_064_Hypothesis_Tournament.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for f in sorted(O.iterdir()):
  if f.is_file():z.write(f,arcname=f.name)
 z.write('/mnt/data/IVTFF Eva.txt.docx',arcname='IVTFF Eva.txt.docx')
 z.write('/mnt/data/voynich_zodiac_slot_map.csv',arcname='voynich_zodiac_slot_map.csv')
 z.write('/mnt/data/voynich_zodiac_clock_positions.csv',arcname='voynich_zodiac_clock_positions.csv')
print('Report length',len(report),'archive size MB',round(Path('/mnt/data/Voynich_Experiment_064_Hypothesis_Tournament.zip').stat().st_size/1e6,2))
