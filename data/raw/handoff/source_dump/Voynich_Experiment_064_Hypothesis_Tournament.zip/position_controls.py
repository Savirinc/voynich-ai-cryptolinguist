#!/usr/bin/env python3
"""Follow-up controls of zodiac ordinals: shuffling vs rotation and familywise correction."""
import pandas as pd, numpy as np, random, math, json, re
from collections import Counter,defaultdict
from pathlib import Path
D=Path('/mnt/data/voynich_tournament_064');rng=random.Random(64134)
data=pd.read_csv('/mnt/data/voynich_zodiac_slot_map.csv').fillna('')
R=[]
for _,x in data.iterrows():
 w=str(x['voynich_label'])
 if not re.fullmatch(r'[a-z]{2,20}',w):continue
 R.append(dict(pref=w[:2],sign=str(x['sign']),page=str(x['folio']),ring=str(x['ring']),ordinal=int(x['transcription_order'])-1))
keys=[5,7,10,15,30]; n=len(R)
def stat(rows,k):
 base=Counter(r['pref'] for r in rows)
 bins=defaultdict(Counter)
 for r in rows:bins[r['ordinal']%k][r['pref']]+=1
 s=0
 for ct in bins.values():
  total=sum(ct.values())
  for w,c in ct.items():s+=(c/n)*math.log2((c/total)/(base[w]/n))
 return s
actual=np.array([stat(R,k) for k in keys])
blocks=defaultdict(list)
for ix,r in enumerate(R):blocks[(r['page'],r['ring'])].append(ix)
null_shuffle=[]; null_rotate=[]
for z in range(3000):
 vals=[]
 for null_type in ['shuffle','rotate']:
  v=[dict(x) for x in R]
  for inds in blocks.values():
   fields=[v[i]['pref'] for i in inds]
   if null_type=='shuffle':rng.shuffle(fields)
   elif len(fields)>1:
    d=rng.randrange(len(fields));fields=fields[d:]+fields[:d]
   for i,p in zip(inds,fields):v[i]['pref']=p
  vals.append([stat(v,k) for k in keys])
 null_shuffle.append(vals[0]);null_rotate.append(vals[1])
s=np.array(null_shuffle);c=np.array(null_rotate)
# Familywise: observed maximum standardized excess from null expectations;
# for a given null world compute the same maximum normalized across tested k.
def family_adjust(null):
 mean=null.mean(axis=0);sd=null.std(axis=0);sd=np.maximum(sd,1e-8)
 zs=(actual-mean)/sd; znull=((null-mean)/sd).max(axis=1)
 return zs,[(1+int((znull>=z).sum()))/(len(znull)+1) for z in zs]
zs,adj=family_adjust(s);zc,adjc=family_adjust(c)
out=[]
for i,k in enumerate(keys):
 out.append({'ordinal_modulus':k,'observed_MI_bits':round(float(actual[i]),5),
 'shuffled_null_mean':round(float(s[:,i].mean()),5),
 'shuffled_p':round((1+int((s[:,i]>=actual[i]).sum()))/(len(s)+1),5),
 'shuffled_familywise_p':round(adj[i],5),
 'cyclic_null_mean':round(float(c[:,i].mean()),5),
 'cyclic_p':round((1+int((c[:,i]>=actual[i]).sum()))/(len(c)+1),5),
 'cyclic_familywise_p':round(adjc[i],5)})
(D/'zodiac_position_stronger_controls.csv').write_text(pd.DataFrame(out).to_csv(index=False))
(D/'zodiac_position_stronger_controls.json').write_text(json.dumps({'n_labels':n,'n_blocks':len(blocks),'permutes':3000,'tests':out},indent=2))
print(pd.DataFrame(out).to_string(index=False))
