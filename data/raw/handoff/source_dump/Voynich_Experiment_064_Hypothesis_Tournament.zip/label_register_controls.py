#!/usr/bin/env python3
"""Control label/prose register within same folios, plus q-o distribution on entire source."""
from docx import Document
from collections import defaultdict,Counter
from pathlib import Path
import math,re,json
OUT=Path('/mnt/data/voynich_tournament_064')
folios=defaultdict(lambda:defaultdict(list))
for p in Document('/mnt/data/IVTFF Eva.txt.docx').paragraphs:
 s=p.text.strip()
 a=re.match(r'^<(f\d+[rv]\d*)\.(\d+),([^>]+)>\s*(.*)',s)
 if not a:continue
 f,num,loc,body=a.groups();group='P' if 'P' in loc else ('L' if 'L' in loc else None)
 if not group:continue
 body=re.sub(r'<![^>]*>',' ',body);body=re.sub(r'<(?:%|\$|-)>','',body)
 toks=[w for w in re.split(r'[.,\s]+',body) if re.fullmatch('[a-z]{2,20}',w)]
 folios[f][group].extend(toks)
obs=0;expected=0;variance=0;both=[]
for fol,groups in folios.items():
 if not groups['L'] or not groups['P']:continue
 n=len(groups['L']);m=len(groups['P']);N=n+m
 a=sum(x.startswith('q') for x in groups['L']);b=sum(x.startswith('q') for x in groups['P']);K=a+b
 obs+=a;expected+=n*K/N
 variance+=n*(K/N)*(1-K/N)*(N-n)/(N-1)
 both.append({'folio':fol,'labels':n,'label_q':a,'prose':m,'prose_q':b})
qs=Counter()
for groups in folios.values():
 for w in groups['P']:
  if w.startswith('q'):qs[w[1] if len(w)>1 else '']=qs[w[1] if len(w)>1 else '']+1
out={'both_types_folios':len(both),'observed_label_q':obs,'random_reassignment_expected_label_q':expected,
 'random_reassignment_sd':math.sqrt(variance),'zscore':(obs-expected)/math.sqrt(variance),
 'after_initial_q_all_prose':dict(qs),'q_initial_followed_o_rate':qs['o']/sum(qs.values()),
 'note':'Random reallocation within folio is a register association test, not a grammar or semantic identification.'}
(OUT/'label_prose_register_control.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
