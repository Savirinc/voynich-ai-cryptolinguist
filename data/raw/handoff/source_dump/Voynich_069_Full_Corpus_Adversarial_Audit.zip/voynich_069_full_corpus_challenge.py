import pandas as pd, numpy as np, json, collections
p='/mnt/data/voynich_tournament_064/indexed_clean_corpus.csv'
d=pd.read_csv(p).fillna('')
d=d[d['mode']=='prose'].copy()
lex={'chedy':'DEUS','shedy':'HEUS','lchedy':'MEUS','qol':'NON','qokol':'NOCET','chol':'DAT','daiin':'OLEUM','oly':'FLOS','okaiin':'FOCUM'}
d['latin']=d.EVA.map(lex).fillna('')
lines=[g.sort_values('token_index_in_line').latin.tolist() for _,g in d.groupby(['folio','line_id'],sort=False)]
def pairs(lines):
 c=collections.Counter();un=collections.Counter()
 for a in lines:
  for x in a:
   if x:un[x]+=1
  for x,y in zip(a,a[1:]):
   if x and y:c[(x,y)]+=1
 return c,un
observed,un=pairs(lines)
targets=[('DEUS','MEUS'),('MEUS','DEUS'),('NON','NOCET'),('OLEUM','FLOS'),('FLOS','OLEUM'),('OLEUM','FOCUM'),('OLEUM','DAT'),('DEUS','DEUS'),('HEUS','DEUS')]
rng=np.random.default_rng(69021)
N=1500
sim={str(x):[] for x in targets}
for _ in range(N):
 shuf=[rng.permutation(a).tolist() if len(a)>1 else a for a in lines]
 cc,_=pairs(shuf)
 for pair in targets:sim[str(pair)].append(cc[pair])
summary=[]
for pair in targets:
 v=np.array(sim[str(pair)]);o=observed[pair]
 summary.append({'phrase':' '.join(pair),'observed_adjacent':o,'permuted_expected':round(float(v.mean()),3),'permuted_95_range':[int(np.quantile(v,.025)),int(np.quantile(v,.975))],'p_enriched':round(float((1+(v>=o).sum())/(N+1)),4),'p_depleted':round(float((1+(v<=o).sum())/(N+1)),4)})
from collections import Counter
bysect={}
for v,g in d.groupby('section'):
 bysect[str(v)]={'tokens':len(g),'proposed_OLEUM':int((g.latin=='OLEUM').sum()),'proposed_DEUS':int((g.latin=='DEUS').sum())}
res={'dataset':p,'prose_tokens':len(d),'folios':int(d.folio.nunique()),'claimed_mapping_tokens':int(d.latin.ne('').sum()),'claimed_mapping_percent':round(100*d.latin.ne('').mean(),2),'claimed_word_frequency':dict(un),'by_section':bysect,'fixed_two_word_claims':summary,'note':'Only 9 fixed mappings from publicly documented Schechter proposal. NOT a test of entire 3,648+ glossary; source glossary was not locally downloadable. Within-line permutations keep word counts and lines fixed, test phrase association only.'}
with open('/mnt/data/voynich_069_results.json','w') as f:json.dump(res,f,indent=2)
print(json.dumps(res,indent=2))
