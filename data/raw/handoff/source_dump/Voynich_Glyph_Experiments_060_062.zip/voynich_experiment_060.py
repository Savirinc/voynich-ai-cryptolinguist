#!/usr/bin/env python3
"""Voynich Exp 060. Lossless structural tokenisation and held-out EVA coding tests.

Input: user's original IVTFF EVA ZL3b 13-May-2025 DOCX.
No glyphs or meanings claimed to be deciphered.
Whole-numbered-folio 5-fold hold-out to prevent recto/verso leakage.
Score: bits per exact original EVA word (including end-of-word).
Important limitation: reversible tokenisations are alternative coding schemes,
not necessarily alternative linguistic units. Differences are NOT evidence of
a particular sound value or a deciphered cipher key.
"""
import re, json, math, hashlib, statistics
from pathlib import Path
from collections import defaultdict, Counter
from docx import Document

P=Path(__file__).resolve().parent
SRC=P/'IVTFF Eva.txt.docx'

def corpus():
 meta={}; out=[]
 for para in Document(SRC).paragraphs:
  s=para.text.strip()
  m=re.match(r'^<(f\d+[rv](?:\d+)?)>\s*<!([^>]+)>',s)
  if m:
   f,h=m.groups(); v=re.search(r'\$L=([AB])',h)
   meta[f]=v.group(1) if v else '?'
  m=re.match(r'^<(f\d+[rv](?:\d+)?)\.(\d+),([^>]+)>\s*(.*)',s)
  if not m:continue
  f,num,loc,body=m.groups()
  if 'P' not in loc:continue
  body=re.sub(r'<![^>]*>',' ',body)
  body=re.sub(r'<(?:%|\$|-)>','',body)
  terms=re.split(r'[.,\s]+',body)
  for t in terms:
   if re.fullmatch('[a-z]{2,20}',t):
    out.append((f,meta.get(f,'?'),t))
 return out

def fold(f):
 leaf=re.match(r'f(\d+)',f).group(1)
 return int(hashlib.sha256(('vo ynich-minims-060:'+leaf).encode()).hexdigest()[:8],16)%5

def segment(w,merges):
 """Greedy longest-match, reversible (each token is a literal EVA string)."""
 if not merges:return tuple(w)
 merges=sorted(merges,key=lambda s:(-len(s),s))
 ans=[]; i=0
 while i<len(w):
  for x in merges:
   if w.startswith(x,i):ans.append(x);i+=len(x);break
  else:ans.append(w[i]);i+=1
 assert ''.join(ans)==w
 return tuple(ans)

class SmoothedNgram:
 def __init__(self,words,merges,order=3):
  self.merges=merges
  self.order=order
  self.uni=Counter();self.big=defaultdict(Counter);self.tri=defaultdict(Counter)
  self.btot=Counter();self.ttot=Counter()
  self.n=0; self.types=set()
  for w in words:
   s=segment(w,merges)
   z=['<BOS>','<BOS>',*s,'<EOS>']
   for i in range(2,len(z)):
    a,b,c=z[i-2:i+1]
    self.types.add(c)
    self.uni[c]+=1;self.big[b][c]+=1;self.btot[b]+=1
    self.tri[(a,b)][c]+=1;self.ttot[(a,b)]+=1
    self.n+=1
  # Holds probability for unseen EVA letters under any segmentation
  self.types|=set('abcdefghijklmnopqrstuvwxyz')|{'<EOS>'}
  self.V=len(self.types)
 def logword(self,w):
  s=segment(w,self.merges)
  z=['<BOS>','<BOS>',*s,'<EOS>']
  loss=0.
  for i in range(2,len(z)):
   a,b,c=z[i-2:i+1]
   # hierarchical interpolation with fixed, not test-tuned smoothing.
   p0=(self.uni[c]+0.25)/(self.n+0.25*self.V)
   p1=(self.big[b][c]+4*p0)/(self.btot[b]+4)
   p2=(self.tri[(a,b)][c]+3*p1)/(self.ttot[(a,b)]+3)
   loss-=math.log2(p2)
  return loss

def boot_ci(folios_delta,B=300,seed=42):
 import random
 rng=random.Random(seed)
 fs=list(folios_delta)
 vals=[folios_delta[f] for f in fs]
 means=[]
 for _ in range(B):
  sampled=[vals[rng.randrange(len(vals))] for _ in vals]
  s=sum(d*n for d,n in sampled); nn=sum(n for d,n in sampled)
  means.append(s/nn)
 means.sort()
 return [means[int(.025*B)],means[int(.975*B)]]

def main():
 tokens=corpus()
 # order tests are deliberately fixed in advance.
 specs={
  'raw_eva':[],
  'bench_ch_sh':['ch','sh'],
  'minims_in_iin_iiin':['iiin','iin','in'],
  'bench_plus_minims':['ch','sh','iiin','iin','in'],
  'bench_minims_plus_qo':['ch','sh','iiin','iin','in','qo'],
  'q_o_unit_only':['qo'],
  'context_pair_controls_al_ar':['ch','sh','al','ar'],
  'context_pair_controls_dy_ey':['ch','sh','dy','ey'],
  'context_pair_controls_ai_oi':['ch','sh','ai','oi'],
  'bench_minims_plus_al_ar':['ch','sh','iiin','iin','in','al','ar'],
  'single_m_unaltered':['ch','sh','iin','in'], # no claim EVA m = iin
 }
 words_by_fold=[[] for _ in range(5)]
 by_fold_folios=[set() for _ in range(5)]
 for f,var,w in tokens:
  k=fold(f)
  words_by_fold[k].append(w);by_fold_folios[k].add(f)
 result={
  'experiment':'060',
  'source':'ZL3b EVMT 2025 IVTFF EVA from uploaded DOCX',
  'n_words':len(tokens),
  'n_folio_sides_and_panels':len(set(f for f,_,_ in tokens)),
  'n_numbered_leaves':len(set(re.match(r'f(\d+)',f).group(1) for f,_,_ in tokens)),
  'methods':'fixed hierarchical trigram smoothing; exact EVA word + EOS; five held-out numbered-folio folds',
  'folds':[],
 }
 all_models={n:[] for n in specs}
 per_folio={n:defaultdict(lambda:[0.,0]) for n in specs}
 for k in range(5):
  train=[w for j in range(5) if j!=k for w in words_by_fold[j]]
  test=words_by_fold[k]
  assert train and test
  result['folds'].append({'fold':k,'train_n':len(train),'test_n':len(test),'folio_n':len(by_fold_folios[k])})
  for name,merges in specs.items():
   mod=SmoothedNgram(train,merges)
   tot=sum(mod.logword(w) for w in test)
   all_models[name].append({'fold':k,'loss':tot/len(test),'bits_total':tot,'n':len(test),'vocab':mod.V})
   result.setdefault('scores',{}).setdefault(name,0.)
   result['scores'][name]+=tot
 for name,v in result['scores'].items():
  result['scores'][name]=v/len(tokens)
 result['per_fold_scores']={n:[{'fold':v['fold'],'bits_per_word':v['loss']} for v in rows] for n,rows in all_models.items()}
 result['scores_vs_raw']={n:result['scores'][n]-result['scores']['raw_eva'] for n in specs}
 result['scores_vs_bench']={n:result['scores'][n]-result['scores']['bench_ch_sh'] for n in specs}
 # Descriptive counts of proposed groupings; not equivalence/meanings.
 c=Counter(w for _,_,w in tokens)
 result['candidate_group_counts']={x:sum(w.count(x)*n for w,n in c.items()) for x in ['ch','sh','in','iin','iiin','qo','al','ar','dy','ey']}
 result['sequences_examples']={w:{name:segment(w,merges) for name,merges in specs.items() if name in ('raw_eva','bench_plus_minims','bench_minims_plus_qo')} for w in ['daiin','dam','qokaiin','qokam','chedy','otalal']}
 path=P/'voynich_experiment_060_results.json'
 path.write_text(json.dumps(result,indent=2))
 print(json.dumps({'n_words':len(tokens),'score_bits_word':result['scores'],'candidate_counts':result['candidate_group_counts']},indent=2))
 return result
if __name__=='__main__':main()
