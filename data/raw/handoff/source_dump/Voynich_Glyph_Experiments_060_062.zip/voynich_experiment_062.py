#!/usr/bin/env python3
"""Experiment 062: Automatically learned BPE units vs hand-selected composites.
Fixed train/test split by numbered leaf, learned ONLY on train leaves. 
Evaluates exact EVA word coding, not semantic translation or correct glyph identity.
"""
import re, math, json, hashlib, statistics
from pathlib import Path
from collections import Counter,defaultdict
from voynich_experiment_060 import corpus,fold,SmoothedNgram
P=Path(__file__).resolve().parent

def learn_bpe(words,max_merges=24):
 vocab=Counter(words)
 tok={w:tuple(w) for w in vocab}
 rules=[]
 for step in range(max_merges):
  pairs=Counter()
  for w,n in vocab.items():
   t=tok[w]
   pairs.update({}) # no-op
   for a,b in zip(t,t[1:]):
    pairs[(a,b)]+=n
  if not pairs:break
  p,score=pairs.most_common(1)[0]
  rules.append({'step':step+1,'left':p[0],'right':p[1],'symbol':''.join(p),'frequency':score})
  for w,arr in tok.items():
   out=[];j=0
   while j<len(arr):
    if j+1<len(arr) and (arr[j],arr[j+1])==p:
     out.append(''.join(p));j+=2
    else:out.append(arr[j]);j+=1
   tok[w]=tuple(out)
 return rules

def encode(w,rules,n):
 x=list(w)
 for r in rules[:n]:
  a,b=r['left'],r['right']
  z=[];i=0
  while i<len(x):
   if i+1<len(x) and x[i]==a and x[i+1]==b:
    z.append(a+b);i+=2
   else:z.append(x[i]);i+=1
  x=z
 assert ''.join(x)==w
 return tuple(x)

class LM:
 def __init__(self,words,rules,steps):
  self.rules=rules;self.steps=steps
  self.uni=Counter();self.bi=defaultdict(Counter);self.tri=defaultdict(Counter)
  self.bn=Counter();self.tn=Counter();self.n=0
  self.types=set('abcdefghijklmnopqrstuvwxyz')|{'<EOS>'}
  for w in words:
   z=['<BOS>','<BOS>',*encode(w,rules,steps),'<EOS>']
   for i in range(2,len(z)):
    a,b,c=z[i-2:i+1]
    self.types.add(c)
    self.uni[c]+=1;self.bi[b][c]+=1;self.bn[b]+=1
    self.tri[(a,b)][c]+=1;self.tn[(a,b)]+=1;self.n+=1
  self.v=len(self.types)
 def loss(self,w):
  z=['<BOS>','<BOS>',*encode(w,self.rules,self.steps),'<EOS>']
  l=0
  for i in range(2,len(z)):
   a,b,c=z[i-2:i+1]
   p0=(self.uni[c]+.25)/(self.n+.25*self.v)
   p1=(self.bi[b][c]+4*p0)/(self.bn[b]+4)
   p2=(self.tri[(a,b)][c]+3*p1)/(self.tn[(a,b)]+3)
   l-=math.log2(p2)
  return l
def main():
 data=corpus()
 grouped=[[] for _ in range(5)]
 for f,v,w in data:grouped[fold(f)].append(w)
 res={'experiment':'062','n_tokens':len(data),'folds':[],'per_fold_scores':{}}
 for k in range(5):
  train=[w for j in range(5) if j!=k for w in grouped[j]]
  test=grouped[k]
  rules=learn_bpe(train,32)
  scores={}
  for n in [0,4,8,16,24,32]:
   model=LM(train,rules,n)
   scores[str(n)]=sum(model.loss(w) for w in test)/len(test)
  res['folds'].append({'fold':k,'training_n':len(train),'test_n':len(test),'first_16_merges':rules[:16],'scores_bits_word':scores})
 res['aggregate_bits_word']={str(n):sum(f['scores_bits_word'][str(n)]*f['test_n'] for f in res['folds'])/len(data) for n in [0,4,8,16,24,32]}
 all_top=Counter(x['symbol'] for f in res['folds'] for x in f['first_16_merges'])
 res['top_merge_consensus']=[{'unit':w,'folds_out_of_5':k} for w,k in all_top.most_common()]
 (P/'voynich_experiment_062_results.json').write_text(json.dumps(res,indent=2))
 print(json.dumps({'aggregate_bits_word':res['aggregate_bits_word'],'top_merges':res['top_merge_consensus'][:25]},indent=2))
 return res
if __name__=='__main__':main()
