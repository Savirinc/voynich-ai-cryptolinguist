#!/usr/bin/env python3
"""Experiment 061: Are proposed Voynich composite units uniquely predictive?

Paired fold/folio comparisons, trigram AND bigram, independent A/B slices.
No semantic claims. All tokenizations are lossless, so there is no actual
evidence about phonemes or pen strokes without high-resolution scan review.
"""
import re, json, random, statistics, math
from pathlib import Path
from collections import defaultdict,Counter
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from voynich_experiment_060 import corpus, fold, segment, SmoothedNgram
P=Path(__file__).resolve().parent
SPEC={
 'raw': [],
 'bench': ['ch','sh'],
 'minim': ['iiin','iin','in'],
 'bench_minim': ['ch','sh','iiin','iin','in'],
 'bench_minim_qo':['ch','sh','iiin','iin','in','qo'],
 'bench_dy_ey':['ch','sh','dy','ey'],
 'bench_al_ar':['ch','sh','al','ar'],
}
def logword(m,w,order):
 z=['<BOS>','<BOS>',*segment(w,m.merges),'<EOS>']
 val=0
 for i in range(2,len(z)):
  a,b,c=z[i-2:i+1]
  p0=(m.uni[c]+.25)/(m.n+.25*m.V)
  p1=(m.big[b][c]+4*p0)/(m.btot[b]+4)
  p2=(m.tri[(a,b)][c]+3*p1)/(m.ttot[(a,b)]+3)
  val-=math.log2((p1 if order==2 else p2))
 return val
def boot(values,B=2000,seed=617):
 r=random.Random(seed);vv=list(values.values());n=len(vv)
 vals=[]
 for _ in range(B):
  s=t=0
  for _ in range(n):
   x,z=vv[r.randrange(n)];s+=x;t+=z
  vals.append(s/t)
 vals.sort()
 return [vals[int(.025*B)],vals[int(.975*B)]]
def main():
 rows=corpus()
 grouped=[[] for _ in range(5)]
 for f,var,w in rows:
  grouped[fold(f)].append((f,var,w))
 details={}
 for order in [2,3]:
  by_folio={model:defaultdict(lambda:[0.,0]) for model in SPEC}
  by_var={model:defaultdict(lambda:[0.,0]) for model in SPEC}
  for k in range(5):
   train=[w for h in range(5) if h!=k for _,_,w in grouped[h]]
   test=grouped[k]
   models={name:SmoothedNgram(train,seq) for name,seq in SPEC.items()}
   for f,var,w in test:
    for name,m in models.items():
     loss=logword(m,w,order)
     leaf=re.match(r'f(\d+)',f).group(1)
     by_folio[name][leaf][0]+=loss;by_folio[name][leaf][1]+=1
     by_var[name][var][0]+=loss;by_var[name][var][1]+=1
  sums={n:sum(x[0] for x in by_folio[n].values())/len(rows) for n in SPEC}
  comps={}
  for name in SPEC:
   if name=='raw':continue
   vals={}
   base='bench' if name.startswith('bench_') else 'raw'
   for leaf,(s,n) in by_folio[name].items():
    vals[leaf]=(s-by_folio[base][leaf][0],n)
   comps[name]={'comparator':base,'mean_delta_bits_word':sum(v[0] for v in vals.values())/len(rows),
     'bootstrap_95pct':boot(vals)}
  details[str(order)]={'scores':sums,'comparisons':comps,'by_variety':{name:{v:(s/n if n else None) for v,(s,n) in by_var[name].items()} for name in SPEC}}
 # Positional feature facts (not meaning).
 counts={x:Counter() for x in ['i','n','m','q','d']}
 for f,var,w in rows:
  for x in counts:
   counts[x]['occurrences']+=w.count(x)
   counts[x]['final']+=int(w.endswith(x))
   counts[x]['initial']+=int(w.startswith(x))
   counts[x]['interior']+=w[1:-1].count(x)
 position={x:dict(c) for x,c in counts.items()}
 results={'experiment':'061','n_words':len(rows),
   'distinct_folio_numbers':len(set(re.match(r'f(\d+)',f).group(1) for f,_,_ in rows)),
   'model':details, 'positions':position,
   'limitations':['Candidate EVA groupings do not prove underlying glyph identities.',
     'Fixed hierarchical ngram models have representation-sensitive smoothing.',
     'Only transcription-level evidence analyzed, not microscopic pen strokes.',
     'Candidate models exploratory, multiple comparisons not adjusted.'
    ]}
 (P/'voynich_experiment_061_results.json').write_text(json.dumps(results,indent=2))
 print(json.dumps({'n':len(rows),
  'bigram':details['2']['scores'],'trigram':details['3']['scores'],
  'trigram_comparison':details['3']['comparisons'],
  'glyph_positions':position},indent=2))
 return results
if __name__=='__main__':main()
