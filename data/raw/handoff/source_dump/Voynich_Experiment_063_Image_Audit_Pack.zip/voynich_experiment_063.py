#!/usr/bin/env python3
"""Exp 063 reproducible EVA glyph-candidate overlap audit.

Source: ZL3b-n IVTFF EVA transcription in IVTFF Eva.txt.docx (user-provided).
This code measures STRING OVERLAP; it does not identify phonetic identity or image strokes.
"""
from pathlib import Path
from docx import Document
from collections import Counter
import re, json, csv
HERE=Path(__file__).resolve().parent
SRC=HERE/'IVTFF Eva.txt.docx'
source=Document(str(SRC))
counts=Counter()
lines={}
for p in source.paragraphs:
    s=p.text.strip()
    match=re.match(r'^<(f\d+[rv]\d*)\.(\d+),([^>]+)>\s*(.*)',s)
    if not match: continue
    folio,line,loc,body=match.groups()
    if 'P' not in loc:continue
    body=re.sub(r'<![^>]*>',' ',body)
    body=re.sub(r'<(?:%|\$|-)>','',body)
    pieces=[w for w in re.split(r'[.,\s]+',body) if w]
    tokens=[w for w in pieces if re.fullmatch('[a-z]{2,20}',w)]
    counts.update(tokens)
    lines[(folio,int(line))]=s
m_tokens=sum(n for w,n in counts.items() if w.endswith('m'))
m_types=[w for w in counts if w.endswith('m')]
suffixes=['iin','in','r','l','n','iiin','dy','id','y','d']
controls=[]
for repl in suffixes:
    token_hits=sum(counts[w] for w in m_types if w[:-1]+repl in counts)
    type_hits=sum(1 for w in m_types if w[:-1]+repl in counts)
    controls.append(dict(replacement='m -> '+repl,matching_m_tokens=token_hits,percent_m_tokens=round(100*token_hits/m_tokens,2),matching_m_types=type_hits))

cases=[
 ('f46v',1,'daiin','f46v',3,'dam','High: independent transcribers agree on both; both physically at line ends'),
 ('f34v',2,'oldam','f34v',9,'oldaiin','Medium: Stolfi records oldaiiin with one extra i; other transcribers read oldaiin'),
 ('f3r',20,'aiin','f3r',20,'am','Medium-high: word boundary differs near s/aiin between transcribers, am stable'),
 ('f8r',19,'kaiin','f8r',19,'kam','Low: ZL has dai,kam and comma indicates uncertain boundary; cannot use as a secure independent token'),
 ('f6r',2,'daiin','f6r',3,'dam','Medium: two different line positions; daiin not at end of line'),
]
case_rows=[]
for f,l,w,f2,l2,w2,status in cases:
    case_rows.append({'folio':f,'line_a':l,'word_a':w,'line_b':l2,'word_b':w2,'audit_status':status,'raw_a':lines.get((f,l),''),'raw_b':lines.get((f2,l2),'')})

result={'source':SRC.name,'parse_note':'Conservative alphabetic tokens from P lines; uncertain characters excluded; punctuation treated as separators for counts, even though some commas mark disputed boundaries.',
 'running_word_tokens':sum(counts.values()),'word_types':len(counts),
 'm_terminal_tokens':m_tokens,'m_terminal_types':len(m_types),
 'controls':controls,'cases':case_rows,
 'limitation':'All matching rates are corpus string overlaps, not proof of same meaning. f8r kam has uncertain boundary and is not high-confidence.'}
(HERE/'voynich_experiment_063_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
with (HERE/'voynich_experiment_063_cases.csv').open('w',newline='',encoding='utf-8') as out:
    dw=csv.DictWriter(out,fieldnames=case_rows[0].keys());dw.writeheader();dw.writerows(case_rows)
print('running tokens',sum(counts.values()),'m tokens',m_tokens,'m types',len(m_types))
for x in controls:print(x)
