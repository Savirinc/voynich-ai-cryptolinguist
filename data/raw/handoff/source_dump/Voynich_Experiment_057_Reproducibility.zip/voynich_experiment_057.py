"""Voynich Experiment 057: Distinguish line-boundary orthography from word-context grammar.

Input: user uploaded IVTFF EVA ZL3b DOCX. Follows original word/locus markers; skips
uncertain tokens rather than inventing values. Train/test folios from 052 hash split.
Reports suffix pair behavior at ordinary line endings vs paragraph endings,
q-prefix carryover across same-line/continuation/new paragraph boundaries,
stratification by Currier A/B, and negative-ending controls.
"""
import re, json, hashlib
from pathlib import Path
from collections import Counter,defaultdict
from docx import Document
import numpy as np
from scipy.stats import fisher_exact
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import log_loss,roc_auc_score

P=Path('/mnt/data'); doc=Document(P/'IVTFF Eva.txt.docx')
lines=defaultdict(dict); meta={}
for paragraph in doc.paragraphs:
 s=paragraph.text.strip()
 h=re.match(r'^<(f\d+[rv](?:\d+)?)>\s*<!([^>]+)>',s)
 if h:
  f,m=h.groups(); l=re.search(r'\$L=([AB])',m); sec=re.search(r'\$I=([A-Z])',m)
  meta[f]=(l[1] if l else '?',sec[1] if sec else '?')
 m=re.match(r'^<(f\d+[rv](?:\d+)?)\.(\d+),([^>]+)>\s*(.*)',s)
 if not m:continue
 f,no,loc,raw=m.groups()
 if 'P' not in loc:continue
 # The first item must be an actual word, not an editorial markup interruption.
 raw_clean=re.sub(r'<![^>]*>',' ',raw)
 # Recognize IVTFF structural markers without discarding adjacent clear words.
 raw_clean=re.sub(r'<(?:%|\$|-)>','',raw_clean)
 pieces=[z for z in re.split(r'[.,\s]+',raw_clean) if z]
 tokens=[z if re.fullmatch('[a-z]{2,20}',z) else None for z in pieces]
 if tokens:lines[f][int(no)]={'tokens':tokens,'loc':loc,'raw':raw}

folios=sorted(lines)
test_fol={f for f in folios if int(hashlib.sha256(('voynich052:'+f).encode()).hexdigest(),16)%5==0}
rows=[]
for f in folios:
 var,sec=meta.get(f,('?','?'))
 for no, rec in lines[f].items():
  tok=rec['tokens']; loc=rec['loc']; raw=rec['raw']
  for j,w in enumerate(tok):
   if w is None:continue
   is_start=j==0;is_end=j==len(tok)-1
   is_para_start=is_start and (loc.startswith('*') or loc.startswith('@'))
   is_para_end=is_end and ('<$>' in raw or loc.startswith('='))
   if is_start:
    other=lines[f].get(no-1)
    prev=other['tokens'][-1] if other and other['tokens'] else None
    boundary='paragraph' if is_para_start else 'continuation'
   else:
    prev=tok[j-1];boundary='within'
   rows.append(dict(folio=f,variety=var,section=sec,line=no,word=w,stem='',prev=prev,
                    boundary=boundary,para_start=is_para_start,
                    line_end=is_end,para_end=is_para_end,
                    ordinary_line_end=(is_end and not is_para_end),
                    split='test' if f in test_fol else 'train'))

trainwords=Counter(r['word'] for r in rows if r['split']=='train')
valid_m={w[:-1] for w,n in trainwords.items() if w.endswith('m') and n>=2 and trainwords[w[:-1]+'iin']>=2}
valid_q={w for w,n in trainwords.items() if w.startswith('o') and n>=2 and trainwords['q'+w]>=2}
endrows=[];qrows=[]
for r in rows:
 w=r['word']; d=dict(r)
 if w.endswith('m') and w[:-1] in valid_m: d['stem']=w[:-1];d['response']=1;endrows.append(d)
 elif w.endswith('iin') and w[:-3] in valid_m: d['stem']=w[:-3];d['response']=0;endrows.append(d)
 if r['prev'] is None:continue
 d=dict(r)
 if w.startswith('qo') and w[1:] in valid_q:d['stem']=w[1:];d['response']=1;qrows.append(d)
 elif w in valid_q:d['stem']=w;d['response']=0;qrows.append(d)

def ctab(data,key,fields):
 groups={}
 for name,fn in fields.items():
  ss=[r for r in data if fn(r)]; z=Counter(r['response'] for r in ss)
  groups[name]={'n':len(ss),'modified':z[1], 'unmodified':z[0], 'modified_rate':z[1]/len(ss) if ss else None}
 return groups

def bootstrap_ratios(data,a,b,nboot=1600,seed=57):
 fs=sorted({r['folio'] for r in data}); by=defaultdict(list)
 for r in data:by[r['folio']].append(r)
 rng=np.random.default_rng(seed); out=[]
 for i in range(nboot):
  chosen=rng.choice(fs,len(fs),replace=True)
  aa=bb=cc=dd=0
  for fol in chosen:
   for r in by[fol]:
    if a(r):aa+=r['response'];bb+=1-r['response']
    if b(r):cc+=r['response'];dd+=1-r['response']
  out.append(np.log((aa+.5)*(dd+.5)/((bb+.5)*(cc+.5))))
 return list(map(float,np.quantile(np.exp(out),[.025,.5,.975])))

te=[r for r in endrows if r['split']=='test'];tr=[r for r in endrows if r['split']=='train']
fields={'within_line':lambda r:not r['line_end'],
        'ordinary_line_end':lambda r:r['ordinary_line_end'],
        'paragraph_end':lambda r:r['para_end'],
        'all_line_end':lambda r:r['line_end']}
suffix_rates=ctab(te,None,fields)
suffix_OR=bootstrap_ratios(te,lambda r:r['ordinary_line_end'],lambda r:not r['line_end'])
# Different sections A/B; output only if N>=30
suffix_var={c:ctab([r for r in te if r['variety']==c],None,fields) for c in ('A','B')}
# Prediction based on stem and variety as fixed intercepts; include whether last, or paragraph last

def fit_suffix(features):
 train=[r for r in tr if r['variety'] in ('A','B')];test=[r for r in te if r['variety'] in ('A','B')]
 def ex(r):return [r['stem'],r['variety']]+[int(r[k]) for k in features]
 Xtr=[ex(r) for r in train];Xte=[ex(r) for r in test];y=np.array([r['response'] for r in test])
 enc=ColumnTransformer([('cat',OneHotEncoder(handle_unknown='ignore'),[0,1])]+([('num','passthrough',list(range(2,len(Xtr[0]))))] if features else []))
 model=make_pipeline(enc,LogisticRegression(C=.7,max_iter=1500))
 model.fit(Xtr,[r['response'] for r in train]); prob=model.predict_proba(Xte)[:,1]
 return {'features':features,'heldout_n':len(y),'log_loss':float(log_loss(y,prob,labels=[0,1])),'auc':float(roc_auc_score(y,prob)),'coefficients':dict(zip(features,map(float,model[-1].coef_[0][-len(features):]))) if features else {}},prob,y,np.array([r['folio'] for r in test])
fits=[fit_suffix(f) for f in [[],['line_end'],['ordinary_line_end','para_end']]]
models=[z[0] for z in fits]
# folio bootstrap gain from ordinary vs end only
folio,y= fits[0][3],fits[0][2];p0=fits[0][1];p1=fits[1][1];p2=fits[2][1]
rng=np.random.default_rng(58);uv=sorted(set(folio));gains=[]
for _ in range(1600):
 sampled=rng.choice(uv,len(uv),replace=True)
 inds=np.concatenate([np.flatnonzero(folio==f) for f in sampled])
 gains.append((log_loss(y[inds],p0[inds],labels=[0,1])-log_loss(y[inds],p2[inds],labels=[0,1]),
               log_loss(y[inds],p1[inds],labels=[0,1])-log_loss(y[inds],p2[inds],labels=[0,1])))
gains=np.array(gains)
# q precursor by within, continued line, or new paragraph
q_te=[r for r in qrows if r['split']=='test' and r['variety'] in ('A','B')];q_tr=[r for r in qrows if r['split']=='train' and r['variety'] in ('A','B')]
qgroups={}
for name in ['within','continuation','paragraph']:
 sub=[r for r in q_te if r['boundary']==name]
 z=Counter((r['prev'].endswith('y'),r['response']) for r in sub)
 T=[[z[True,1],z[True,0]],[z[False,1],z[False,0]]]
 odds,p=fisher_exact(T)
 qgroups[name]={'n':len(sub),'table':T,'q_after_y':z[True,1]/max(1,z[True,1]+z[True,0]),'q_after_other':z[False,1]/max(1,z[False,1]+z[False,0]),'unadjusted_odds':float(odds),'fisher_p':float(p)}

# report structural integrity warning edge cases
line_stats=Counter((r['boundary'],r['split']) for r in qrows)
res={'experiment':'057','source':'User-uploaded ZL3b-n IVTFF EVA transcription','parsing':{'clean_running_tokens':len(rows),'folios':len(folios),'matched_q_stems':len(valid_q),'matched_suffix_stems':len(valid_m), 'q_boundary_distribution':{str(k):v for k,v in line_stats.items()}},
 'suffix_m_vs_iin':{'heldout_rates':suffix_rates,'heldout_rates_by_currier':suffix_var,'ordinary_line_end_vs_within_line_OR_bootstrap_CI95':suffix_OR,'model_comparison':models,'gain_CI95':{'vs_stem_variety':list(map(float,np.quantile(gains[:,0],[.025,.5,.975]))),'vs_binary_line_end':list(map(float,np.quantile(gains[:,1],[.025,.5,.975])))},'heldout_n':len(te),'train_n':len(tr)},
 'prefix_q_vs_o':{'matched_stem_counts':len(valid_q),'heldout':qgroups},
 'cautions':['The transcript contains line/paragraph locus annotations; not independently verified against every Yale page image.', 'This is NOT a decoding of any word or proof that m and iin encode identical underlying units.','Only 5,000-ish q prefix forms; continuation line starts are rare relative to within-line tokens.','Folio-level controls give more honest uncertainty than token-level Fisher tests.']}
(P/'voynich_experiment_057_results.json').write_text(json.dumps(res,indent=2))
print(json.dumps(res,indent=2))
