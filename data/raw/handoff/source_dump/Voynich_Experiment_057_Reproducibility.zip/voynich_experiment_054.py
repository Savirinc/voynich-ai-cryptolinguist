"""Experiment 054: Does q-vs-o onset selection reset at manuscript line breaks?
User corpus: IVTFF Eva.txt.docx (ZL v3b 2025)

Measures cross-boundary contrast, controls for same stem and Currier language
in held-out folios, and uses folio bootstrap confidence intervals.

Warning: A physical line is approximated by each P-locus transcription line;
transcription uncertainty, line breaks within words, and uncertain joins are excluded.
"""
import re,json,hashlib
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np
from docx import Document
from scipy.stats import fisher_exact
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss,roc_auc_score

ROOT=Path('/mnt/data'); PATH=ROOT/'IVTFF Eva.txt.docx'
folios=defaultdict(dict); currier={}; section={}
for para in Document(PATH).paragraphs:
 s=para.text.strip()
 h=re.match(r'^<(f\d+[rv](?:\d+)?)>\s*<!([^>]+)>',s)
 if h:
  fol,met=h.groups()
  cm=re.search(r'\$L=([AB])',met);im=re.search(r'\$I=([A-Z])',met)
  currier[fol]=cm.group(1) if cm else '?';section[fol]=im.group(1) if im else '?'
 m=re.match(r'^<(f\d+[rv](?:\d+)?)\.(\d+),([^>]+)>\s*(.*)',s)
 if not m:continue
 fol,lineno,loc,raw=m.groups()
 if 'P' not in loc:continue
 # Ignore transcriber notes, uncertain / editorial readings, preserve token position nulls.
 raw=re.sub(r'<![^>]*>',' ',raw)
 tok=[t if re.fullmatch(r'[a-z]{2,20}',t) else None for t in re.split(r'[.,\s]+',raw) if t]
 if tok:folios[fol][int(lineno)]=tok

# Prepare cases with exactly defined immediate predecessor, but no pair across folios.
rows=[]
for fol,lines in folios.items():
 for n,words in lines.items():
  for pos,w in enumerate(words):
   if not w or not (w.startswith('qo') or w.startswith('o')):continue
   before=words[pos-1] if pos else (lines.get(n-1,[])[-1] if lines.get(n-1) else None)
   if not before:continue
   rows.append({'folio':fol,'section':section.get(fol,'?'),'currier':currier.get(fol,'?'),
                'stem':w[1:] if w.startswith('qo') else w, 'q':int(w.startswith('qo')),
                'prev_y':int(before.endswith('y')),'line_start':int(pos==0),
                'word':w,'preceding_word':before})

trainf={f for f in folios if int(hashlib.sha256(('voynich052:'+f).encode()).hexdigest(),16)%5!=0}
from collections import Counter
train_c=Counter((r['stem'],r['q']) for r in rows if r['folio'] in trainf)
# Have both surface variants represented repeatedly IN TRAIN, plus correctly classified Currier metadata
valid={s for s,k in train_c if train_c[s,0]>=2 and train_c[s,1]>=2}
rr=[r for r in rows if r['stem'] in valid and r['currier'] in ('A','B')]
train=[r for r in rr if r['folio'] in trainf];test=[r for r in rr if r['folio'] not in trainf]

def describe(sub):
 c=Counter((r['line_start'],r['prev_y'],r['q']) for r in sub)
 out={}
 for state in (0,1):
  a=c[state,1,1];b=c[state,1,0];cc=c[state,0,1];d=c[state,0,0]
  odds,p=fisher_exact([[a,b],[cc,d]])
  out['across_lines' if state else 'within_lines']={'q_after_prev_y':a,'no_q_after_prev_y':b,
  'q_after_other_ending':cc,'no_q_after_other_ending':d,'rate_after_y':a/(a+b) if a+b else None,
  'rate_after_other':cc/(cc+d) if cc+d else None, 'unadjusted_OR':float(odds),'p':float(p)}
 return out

# Compare 3 predictive encodings on independent held-out folios:
# base: same lexical stem and Currier
# global: preceding y and initial-line state each as independent linear factors
# interaction: effect of preceding y differs across lines

def fit(features):
 from sklearn.preprocessing import OneHotEncoder
 trainX=[];testX=[]
 def x(r):return [r['stem'],r['currier']]+[r[f] for f in features]+([r['prev_y']*r['line_start']] if 'interaction' in features else [])
 actual_features=[f for f in features if f!='interaction']
 def x(r):return [r['stem'],r['currier']]+[r[f] for f in actual_features]+([r['prev_y']*r['line_start']] if 'interaction' in features else [])
 trainX=[x(r) for r in train]; testX=[x(r) for r in test]
 enc=ColumnTransformer([('cat',OneHotEncoder(handle_unknown='ignore'),[0,1])]+([('num','passthrough',list(range(2,len(trainX[0]))))] if len(trainX[0])>2 else []))
 model=make_pipeline(enc,LogisticRegression(C=1.0,max_iter=2000))
 model.fit(trainX,[r['q'] for r in train])
 p=model.predict_proba(testX)[:,1];y=np.array([r['q'] for r in test]);
 return {'model':'+'.join(features) if features else 'base', 'log_loss':float(log_loss(y,p,labels=[0,1])),
         'auc':float(roc_auc_score(y,p)), 'coefficients':list(map(float,model[-1].coef_[0][-len(trainX[0])+2:])) if len(trainX[0])>2 else [],'prediction':p}
base=fit([]);globalmodel=fit(['prev_y','line_start']);interactive=fit(['prev_y','line_start','interaction'])

# Cluster bootstrap over held-out folios (not individual tokens), model training fixed.
testf=np.array([r['folio'] for r in test]);Y=np.array([r['q'] for r in test]);U=np.array(sorted(set(testf)))
rng=np.random.default_rng(54); boot=[]
for j in range(1600):
 chosen=rng.choice(U,len(U),replace=True)
 ix=np.concatenate([np.flatnonzero(testf==f) for f in chosen])
 boot.append((float(log_loss(Y[ix],base['prediction'][ix],labels=[0,1])-log_loss(Y[ix],interactive['prediction'][ix],labels=[0,1])),
              float(log_loss(Y[ix],globalmodel['prediction'][ix],labels=[0,1])-log_loss(Y[ix],interactive['prediction'][ix],labels=[0,1]))))
boot=np.array(boot)
# Within-line OR / across-line OR bootstrap by folio; Haldane correction for stability
boot_or=[]
for j in range(1600):
 chosen=rng.choice(U,len(U),replace=True)
 sub=[]
 for f in chosen: sub.extend([r for r in test if r['folio']==f])
 t=describe(sub)
 def lor(v):
  return np.log((v['q_after_prev_y']+.5)*(v['no_q_after_other_ending']+.5)/((v['no_q_after_prev_y']+.5)*(v['q_after_other_ending']+.5)))
 boot_or.append(lor(t['within_lines'])-lor(t['across_lines']))

result={'experiment':'054: Line-reset test for contextual q/o variants','source':'User supplied ZL v3b EVA, 13 May 2025',
 'counts':{'parsed_cases_all':len(rows),'matched_forms_training':len(valid),'train_n':len(train),'test_n':len(test),'test_folios':len(U)},
 'all_raw':describe(rows),'matched_training':describe(train),'matched_heldout':describe(test),
 'models':[{k:v for k,v in model.items() if k!='prediction'} for model in [base,globalmodel,interactive]],
 'cluster_bootstrap':{'gain_interaction_vs_base_ci95':list(np.quantile(boot[:,0],[.025,.5,.975])),
                      'gain_interaction_vs_global_main_effects_ci95':list(np.quantile(boot[:,1],[.025,.5,.975])),
                      'difference_log_OR_within_minus_across_ci95':list(np.quantile(boot_or,[.025,.5,.975]))},
 'caveats':['EVA is not a phonetic alphabet.','The original transcript is line-aligned but some visual breaks and ambiguous words could affect inferred adjacency.',
 'A change across line boundaries does not establish whether grammar or a cipher is responsible.',
 'Reported interactions are based on a preexisting candidate q/o family and cannot alone recover word meaning.']}
(ROOT/'voynich_experiment_054_results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
