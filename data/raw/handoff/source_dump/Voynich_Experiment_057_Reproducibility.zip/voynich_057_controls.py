from pathlib import Path
from docx import Document
from collections import Counter,defaultdict
from scipy.stats import fisher_exact
import re,hashlib,json
P=Path('/mnt/data')
records=[]
for p in Document(P/'IVTFF Eva.txt.docx').paragraphs:
 s=p.text.strip();m=re.match(r'^<(f\d+[rv](?:\d+)?)\.(\d+),([^>]+)>\s*(.*)',s)
 if not m or 'P' not in m[3]:continue
 f,no,loc,raw=m.groups()
 text=re.sub(r'<![^>]*>',' ',raw)
 text=re.sub(r'<(?:%|\$|-)>','',text)
 words=[x if re.fullmatch(r'[a-z]{2,20}',x) else None for x in re.split('[.,\s]+',text) if x]
 for i,w in enumerate(words):
  if w is not None: records.append((f,w,i==len(words)-1))
train=Counter(w for f,w,last in records if int(hashlib.sha256(('voynich052:'+f).encode()).hexdigest(),16)%5!=0)
result={}
for alt,base in [('m','iin'),('m','in'),('g','y'),('in','iin'),('r','l'),('dy','ey')]:
 stems={w[:-len(alt)] for w,c in train.items() if len(w)>len(alt) and w.endswith(alt) and c>=2 and train[w[:-len(alt)]+base]>=2}
 ct=Counter()
 for f,w,last in records:
  if int(hashlib.sha256(('voynich052:'+f).encode()).hexdigest(),16)%5!=0:continue
  if w.endswith(alt) and w[:-len(alt)] in stems:ct[('alt',last)]+=1
  elif w.endswith(base) and w[:-len(base)] in stems:ct[('base',last)]+=1
 T=[[ct['alt',True],ct['base',True]],[ct['alt',False],ct['base',False]]]
 OR,p=fisher_exact(T)
 result[f'{alt} vs {base}']={'stems':len(stems),'table':T,'OR':float(OR),'p':float(p),'line_end_alt_rate':ct['alt',True]/max(1,ct['alt',True]+ct['base',True]),'within_alt_rate':ct['alt',False]/max(1,ct['alt',False]+ct['base',False])}
print(json.dumps(result,indent=2))
(P/'voynich_experiment_057_suffix_controls.json').write_text(json.dumps(result,indent=2))
