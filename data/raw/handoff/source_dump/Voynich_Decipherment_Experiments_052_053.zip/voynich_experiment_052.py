"""Experiment 052: pre-registered scribal surface-rule tests on IVTFF EVA v3b.
Two rival contextual operations:
  (A) word-final -m vs -iin, conditioned on physical transcription line end
  (B) initial q+o versus o, conditioned on preceding word-final y
Evaluates entire held-out folios; reports descriptive and predictive scores.
CAVEAT: A transcription line is used as proxy for manuscript visual line; no glyph-shape mapping.
"""
from pathlib import Path
from docx import Document
import re, hashlib, collections, json, math
import numpy as np
from scipy.stats import fisher_exact
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import make_pipeline
from sklearn.metrics import log_loss, roc_auc_score, accuracy_score

P=Path('/mnt/data')
foliovar={}; rows=[]
for paragraph in Document(P/'IVTFF Eva.txt.docx').paragraphs:
    s=paragraph.text.strip()
    h=re.match(r'^<(f\d+[rv](?:\d+)?)>\s*<!.*?\$L=([AB])',s)
    if h: foliovar[h[1]]=h[2]
    m=re.match(r'^<(f\d+[rv](?:\d+)?)\.(\d+),([^>]+)>\s*(.*)',s)
    if not m or 'P' not in m[3]:continue
    fol,idx,loc,payload=m.groups()
    # A literal Latin a-z word is accepted only if no editorial uncertainty intrudes.
    clean=re.sub(r'<![^>]*>',' ',payload)
    chunks=re.split(r'[.,\s]+',clean)
    tok=[w if re.fullmatch(r'[a-z]{2,20}',w) else None for w in chunks if w]
    if not tok: continue
    for j,w in enumerate(tok):
        if w is None:continue
        prev=tok[j-1] if j>0 else None
        nxt=tok[j+1] if j+1<len(tok) else None
        rows.append({'folio':fol,'variety':foliovar.get(fol,'?'), 'line':int(idx), 'word':w,
                     'prev':prev,'next':nxt,'line_last':j==len(tok)-1,
                     'line_first':j==0})

# FOLIO hash split, stable on repeated runs; force result reproducible
folios=sorted({r['folio'] for r in rows})
tests={f for f in folios if int(hashlib.sha256(('voynich052:'+f).encode()).hexdigest(),16)%5==0}
for r in rows:r['split']='test' if r['folio'] in tests else 'train'

# candidate pairs discovered only in training
trainwords=collections.Counter(r['word'] for r in rows if r['split']=='train')
valid_suffix={stem for w,c in trainwords.items() if w.endswith('m') and c>=2 for stem in [w[:-1]]
              if len(stem)>=1 and trainwords[stem+'iin']>=2}
valid_prefix={w for w,c in trainwords.items() if w.startswith('o') and c>=2 and trainwords['q'+w]>=2}

def test_rows(kind):
    sub=[]
    for r in rows:
        w=r['word']
        if kind=='ending':
            if w.endswith('m') and w[:-1] in valid_suffix:
                lab=1; stem=w[:-1]
            elif w.endswith('iin') and w[:-3] in valid_suffix:
                lab=0; stem=w[:-3]
            else: continue
            context=int(r['line_last'])
        else:
            if w.startswith('q') and w[1:] in valid_prefix:
                lab=1; stem=w[1:]
            elif w in valid_prefix:
                lab=0;stem=w
            else: continue
            if not r['prev']:continue
            context=int(r['prev'].endswith('y'))
        sub.append({**r,'stem':stem,'label':lab,'context':context})
    return sub

def model_test(data,context_name):
    train=[r for r in data if r['split']=='train' and r['variety'] in ('A','B')]
    test=[r for r in data if r['split']=='test' and r['variety'] in ('A','B')]
    def fit_predict(include_context):
        cols=['stem','variety']+(['context'] if include_context else [])
        trainX=[[r[c] for c in cols] for r in train];testX=[[r[c] for c in cols] for r in test]
        categ=list(range(2));numeric=[2] if include_context else []
        transformer=ColumnTransformer([('cat',OneHotEncoder(handle_unknown='ignore'),categ)]+([('num','passthrough',numeric)] if numeric else []))
        clf=make_pipeline(transformer,LogisticRegression(C=0.7,max_iter=1000))
        clf.fit(trainX,[r['label'] for r in train])
        p=clf.predict_proba(testX)[:,1];y=np.array([r['label'] for r in test])
        scores={'n':len(test),'log_loss':float(log_loss(y,p,labels=[0,1])), 'auc':float(roc_auc_score(y,p)),'accuracy':float(accuracy_score(y,p>=0.5))}
        if include_context:
            scores['context_coefficient']=float(clf[-1].coef_[0][-1]);scores['context_odds_factor']=float(np.exp(clf[-1].coef_[0][-1]))
        return scores,p
    null,p0=fit_predict(False);added,p1=fit_predict(True)
    y=np.array([r['label'] for r in test]); testfolio=np.array([r['folio'] for r in test])
    # folio bootstrap: account for intra-folio clustering
    rs=np.random.RandomState(52)
    fols=sorted(set(testfolio));bootstrap=[]
    for i in range(1200):
        sampled=rs.choice(fols,len(fols),replace=True)
        ix=np.concatenate([np.flatnonzero(testfolio==f) for f in sampled])
        bootstrap.append(float(log_loss(y[ix],p0[ix],labels=[0,1])-log_loss(y[ix],p1[ix],labels=[0,1])))
    ci=np.quantile(bootstrap,[.025,.5,.975])
    counts=collections.Counter((r['context'],r['label']) for r in test)
    table=[[counts[(1,1)],counts[(1,0)]],[counts[(0,1)],counts[(0,0)]]]
    odds,pvalue=fisher_exact(table)
    return {'candidate_stems_train':len(set(r['stem'] for r in train)),
            'train_n':len(train),'test_n':len(test),
            'test_folios':len(set(testfolio)), 'control':null,'context_model':added,
            'gain_log_loss':round(null['log_loss']-added['log_loss'],5),
            'folio_bootstrap_gain_CI_95':list(map(float,ci)),
            'heldout_2x2_context1_vs_context0_form1_first':table,
            'heldout_unadjusted_OR':float(odds),'heldout_fisher_p':float(pvalue),
            'heldout_rates':{'context1':counts[(1,1)]/(counts[(1,1)]+counts[(1,0)]),
                             'context0':counts[(0,1)]/(counts[(0,1)]+counts[(0,0)])},
            'examples':[]}
ending=test_rows('ending');prefix=test_rows('prefix')
out={'method':{'source':'User supplied ZL v3b IVTFF EVA transcription, accepted clean P-locus word tokens only; fixed folio hash split 20%',
                'caveats':['Comparing EVA strings does not establish phonemes or glyph identities.',
                           'End of line derived from IVTFF paragraph record, not independently measured from Yale scans.',
                           'A strong positional effect can be a scribal convention, a cipher rule, or underlying grammatical constraints.',
                           'No translation or semantic mapping is inferred.',
                           'Training stem families selected from training folios only.']},
    'corpus':{'tokens':len(rows),'folios':len(folios),'train_folios':len(folios)-len(tests),'heldout_folios':len(tests)},
    'hypothesis_final_m_as_line_end_variant_of_iin':model_test(ending,'line_last'),
    'hypothesis_initial_q_context_of_previous_y':model_test(prefix,'prev_y')}
for name,subset in [('m_iin',ending),('q_o',prefix)]:
    grouped=collections.defaultdict(lambda:collections.Counter())
    for r in subset:
        if r['split']=='test':grouped[r['stem']][(r['label'],r['context'])]+=1
    ex=[]
    for stem,counts in grouped.items():
        if sum(counts.values())>=15 and sum(v for (l,c),v in counts.items() if l==1)>=2 and sum(v for (l,c),v in counts.items() if l==0)>=2:
            ex.append({'stem':stem,'counts':{'alt_context1':counts[(1,1)],'alt_context0':counts[(1,0)],'base_context1':counts[(0,1)],'base_context0':counts[(0,0)]}})
    ex.sort(key=lambda r:-sum(r['counts'].values()))
    out['hypothesis_final_m_as_line_end_variant_of_iin' if name=='m_iin' else 'hypothesis_initial_q_context_of_previous_y']['examples']=ex[:12]
(P/'voynich_experiment_052_results.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
