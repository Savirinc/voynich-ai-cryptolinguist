"""Experiment 053: semantic-bridge audit of labels vs prose and negative suffix controls.
Reads the same user-supplied ZL3b IVTFF transcription; surface-form inference only.
"""
from docx import Document
from collections import Counter,defaultdict
from scipy.stats import fisher_exact
from statsmodels.stats.contingency_tables import StratifiedTable
import numpy as np
import re,json,hashlib
from pathlib import Path
P=Path('/mnt/data')
records=[];lang={}
for p in Document(P/'IVTFF Eva.txt.docx').paragraphs:
 s=p.text.strip();h=re.match(r'^<(f\d+[rv](?:\d+)?)>\s*<!.*?\$L=([AB])',s)
 if h:lang[h[1]]=h[2]
 m=re.match(r'^<(f\d+[rv](?:\d+)?)\.(\d+),([^>]+)>\s*(.*)',s)
 if not m:continue
 f,line,loc,src=m.groups(); kind='P' if 'P' in loc else 'L' if 'L' in loc else None
 if kind is None:continue
 src=re.sub(r'<![^>]*>',' ',src)
 toks=[t for t in re.split(r'[.,\s]+',src) if t]
 for j,t in enumerate(toks):
  if re.fullmatch(r'[a-z]{2,20}',t):records.append(dict(folio=f,kind=kind,word=t,lang=lang.get(f,'?'),line_last=(j==len(toks)-1)))
body=Counter(r['word'] for r in records if r['kind']=='P'); labels=Counter(r['word'] for r in records if r['kind']=='L')
qP=sum(v for w,v in body.items() if w.startswith('q'));qL=sum(v for w,v in labels.items() if w.startswith('q'))
nP=sum(body.values());nL=sum(labels.values())
label_o=sum(v for w,v in labels.items() if w.startswith('o'))
matched_label_o=sum(v for w,v in labels.items() if w.startswith('o') and ('q'+w) in body)

# For exact shared stem, compare the probability of q given same o... word between labels vs prose
sub=defaultdict(lambda:np.zeros((2,2),dtype=int)); observed=Counter()
for r in records:
 w=r['word']; q=int(w.startswith('qo'))
 if q:stem=w[1:]
 elif w.startswith('o'):stem=w
 else:continue
 if len(stem)<2:continue
 row=1 if r['kind']=='L' else 0
 sub[stem][row,q]+=1
 observed[(row,q)]+=1
informative=[]
for stem,arr in sub.items():
 if all(arr.sum(axis=1)>0) and all(arr.sum(axis=0)>0): informative.append(arr)
strat=StratifiedTable(informative)
raw=[ [observed[(1,1)],observed[(1,0)]],[observed[(0,1)],observed[(0,0)]] ]

# Extra test: line-final alternation under other suffix candidates - from heldout ONLY, stems seen >=2 per variant in TRAIN
corpus=[r for r in records if r['kind']=='P']
for r in corpus:r['split']='test' if int(hashlib.sha256(('voynich052:'+r['folio']).encode()).hexdigest(),16)%5==0 else 'train'
tr=Counter(r['word'] for r in corpus if r['split']=='train')
def alt_controls(alt,base):
 stems={w[:-len(alt)] for w,n in tr.items() if w.endswith(alt) and n>=2 and len(w)>len(alt) and tr[w[:-len(alt)]+base]>=2}
 tokens=[]
 for r in corpus:
  if r['split']!='test':continue
  w=r['word']
  if w.endswith(alt) and w[:-len(alt)] in stems:tokens.append((1,int(r['line_last'])))
  elif w.endswith(base) and w[:-len(base)] in stems:tokens.append((0,int(r['line_last'])))
 c=Counter(tokens);table=[[c[1,1],c[0,1]],[c[1,0],c[0,0]]]
 OR,p=fisher_exact(table)
 return {'alternative':alt,'base':base,'paired_training_stems':len(stems),'heldout_n':len(tokens),'line_end_table_alt_vs_base':table,'unadjusted_OR':OR,'p':p,
 'alt_rate_line_end':c[1,1]/(c[1,1]+c[0,1]) if c[1,1]+c[0,1] else None,
 'alt_rate_non_end':c[1,0]/(c[1,0]+c[0,0]) if c[1,0]+c[0,0] else None}
controls=[alt_controls(a,b) for a,b in [('m','iin'),('in','iin'),('r','l'),('dy','ey'),('m','in')]]

# Evidence of local shared same-folio label -> body pair matches.
localP=defaultdict(Counter)
for r in corpus:localP[r['folio']][r['word']]+=1
local=[]
for r in records:
 if r['kind']=='L' and r['word'].startswith('o') and 'q'+r['word'] in localP[r['folio']]:
  local.append({'folio':r['folio'],'label':r['word'],'prose_q_word':'q'+r['word'],'body_frequency_in_same_folio':localP[r['folio']]['q'+r['word']]})
local.sort(key=lambda x:-x['body_frequency_in_same_folio'])
output={'source':'IVTFF EVA 2025 supplied document','tokens':{'prose':nP,'labels':nL,'label_unique':len(labels)},
        'q_first_rate':{'prose':qP/nP,'labels':qL/nL,'prose_q_count':qP,'labels_q_count':qL},
        'o_labels_with_q_prose_counterpart':{'n':matched_label_o,'of':label_o,'rate':matched_label_o/label_o},
        'raw_label_vs_prose_o_q_table':raw, 'stem_control':{'informative_stems':len(informative),'q_in_labels_vs_prose_stratified_OR':float(strat.oddsratio_pooled),'ci95':list(map(float,strat.oddsratio_pooled_confint())),'p':float(strat.test_null_odds().pvalue)},
        'suffix_specificity_controls':controls,'same_folio_label_q_body_examples':local[:35],
        'limitations':['Labels are not proven names; arbitrary plaintext significance is unestablished.','Multiple suffix controls exploratory; odds ratios unadjusted for exact stem in suffix controls.','EVA physical-line segmentation follows supplied transcription.','Some labels may be transcription/illustration uncertain.']}
(P/'voynich_experiment_053_results.json').write_text(json.dumps(output,indent=2))
print(json.dumps(output,indent=2))
